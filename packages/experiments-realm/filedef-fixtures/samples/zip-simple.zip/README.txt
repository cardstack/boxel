FileDef ZIP fixture

This single-file archive validates bounded manifest extraction.
