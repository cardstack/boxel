/**
 * Is anything still moving?
 *
 * Ember Animated's maturity is not its sprite code, it is `animationsSettled()`
 * — a test can say "when everything has stopped" instead of `sleep(200)` and
 * hoping. This is the machinery under that: every part of the binding that can
 * still have work outstanding registers a probe, and a probe answers with a
 * short reason string while it is busy and `false` when it is not.
 *
 * The reason is not decoration. A test that times out waiting for motion is
 * useless if all it can say is "timed out"; `whatIsBusy()` names the element
 * and the property that never stopped, which is usually the bug itself.
 *
 * Deliberately NOT an `@ember/test-waiters` waiter, which would make plain
 * `await settled()` block until animations finish. That reads well in a doc and
 * is wrong here: the interruption suite exists precisely to click again while
 * something is still in flight, and a blocking waiter would turn every one of
 * those into a wait-for-completion — the tests would pass by no longer testing
 * anything. Waiting for motion is a thing a test asks for, not a thing it gets.
 *
 * Probes are module-global rather than owner-linked because the things they
 * watch are: the engine's frameloop, the projection tree and the beacon
 * registry are all one per document, and a probe that could not see across an
 * owner boundary could not see the far-match barrier at all. Registration is
 * still tied to a destructor at every call site, so nothing outlives its
 * element.
 */
/** busy → a short reason; idle → false */
export type BusyProbe = () => false | string;
export declare function registerBusyProbe(probe: BusyProbe): () => void;
/** every reason the binding is not at rest, for a timeout message */
export declare function whatIsBusy(): string[];
export declare function isMotionIdle(): boolean;
//# sourceMappingURL=activity.d.ts.map