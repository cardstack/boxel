/**
 * MotionNode — the lifecycle glue React's `motion` component provides, for one element, with no host
 * framework in it: construct the VisualElement in document order, mount post-order after the render pass,
 * update on every later pass, tear down. `{{motion}}` (motion.ts) is the ember-modifier shell around it;
 * another host wraps it the same way. Same props as the React API:
 *   initial · animate · exit · variants · transition · layout · layoutId · drag… · style · custom
 * plus `presence` (from <Presence>) instead of React context.
 */
import type { MotionNodeOptions, MotionValue, VisualElement } from 'motion-dom';
import type { ChoreoNode } from './choreo/types.ts';
import type { PopMeasurable, PresenceHandle } from './presence-types.ts';
/** React's HTMLMotionProps = MotionNodeOptions + style (static values and MotionValues) */
export type MotionProps = Omit<MotionNodeOptions, 'dragConstraints'> & {
    /** internal Framer props: route the drag gesture straight into these values */
    _dragX?: MotionValue<number>;
    _dragY?: MotionValue<number>;
    /** React accepts a ref object; Glimmer has the element itself, so either is fine */
    dragConstraints?: MotionNodeOptions['dragConstraints'] | Element | null;
    /** choreography: identity across renders, and the group a <Choreo> step selects by */
    id?: string;
    /**
     * How Choreo measures this element for a shape-matched flight.
     * `'box'` (default) is the layout border box — right for plates, cards,
     * stages. `'content'` is the shrink-wrap (the ink): a full-bleed title
     * still matches as a word. Written as `data-choreo-pack`; an explicit
     * `[data-choreo-substance]` descendant still wins.
     */
    pack?: 'box' | 'content';
    presence?: PresenceHandle;
    role?: string;
    style?: Record<string, unknown>;
    /** MotionConfig's transformPagePoint — passed per element here (React merges the config into props) */
    transformPagePoint?: (p: {
        x: number;
        y: number;
    }) => {
        x: number;
        y: number;
    };
};
/** motion.div … motion.circle: any element with an inline style */
export type MotionEl = HTMLElement | SVGElement;
export declare function flushPendingPops(): void;
/** mount everything rendered this pass — idempotent; presence notifications call it first so that a
 *  leaver is refreshed only after its replacement has joined the shared-element stack (React: same commit) */
export declare function flushPendingMounts(): void;
export declare class MotionNode implements ChoreoNode, PopMeasurable {
    private ve?;
    private destroyed;
    /** this node's registration with its presence child (MeasureLayout registers per node) */
    private readonly layoutPresenceKey;
    element?: MotionEl;
    private latest?;
    private lastPresent?;
    private config;
    /** React: configAndProps = { ...MotionConfigContext, ...props }. Looked up when used, not when the args
     *  arrive: modifiers install children-first, so a <MotionConfig> above has not registered yet at update time */
    private configured;
    /** re-configure when the global speed changes, so the next layout animation is born slowed */
    private watchSpeed;
    private unsubscribeSpeed?;
    private stopProbe?;
    private unregister?;
    private popStyle?;
    /** the seat measured before the render that removed this element */
    private popSeat?;
    private unregisterPop?;
    /** boxel-motion's sprite identity: a <Choreo> above selects this element by these */
    id: string | null;
    role: string | null;
    private choreo?;
    private presenceRegistered;
    constructor();
    /** React render: the element's props for this pass */
    update(element: MotionEl, named: MotionProps): void;
    private unsubscribePresence?;
    /** React render: construct the VisualElement (not yet mounted) */
    create(): void;
    /** React effect: mount → update → features → animateChanges */
    mountNow(): void;
    /** every later pass: React's update → updateFeatures → animateChanges */
    private apply;
    /** a participant registers with the nearest region, and with its Presence so a timeline can outlive a plain exit */
    private joinChoreo;
    get visualElement(): VisualElement | undefined;
    get layoutKey(): string;
    /** for the region's @debug lints (§5.3) */
    get ownAnimation(): boolean;
    get presenceManaged(): boolean;
    get isPresent(): boolean;
    /** the choreography is done with a leaving element: tell its Presence */
    exitComplete(): void;
    /** the choreography is done with an element whose unmount it deferred */
    release(): void;
    /** re-run the update pass with the latest args (a context or presence change above us) */
    refresh(): void;
    /** the non-motion-value part of `style` goes straight onto the element, as React's style attribute would —
     *  except keys the engine already owns (it renders those itself, and decides whether a style change applies) */
    private applyStyle;
    /**
     * React's PopChildMeasure.getSnapshotBeforeUpdate: the seat this element
     * occupies, read BEFORE the render that removes it.
     *
     * <Presence> calls this from its own diff, while the arrivals for this pass
     * are still unrendered. Measuring later reads a layout that already holds
     * them — the container has grown, and a centred one has moved — so the
     * leaver would be pinned somewhere it never stood.
     */
    measureForPop(): void;
    /** popLayout: a leaving element is lifted out of flow at its last box so siblings can close up */
    private pop;
    /** React unmount */
    destroy(): void;
}
export default MotionNode;
//# sourceMappingURL=node.d.ts.map