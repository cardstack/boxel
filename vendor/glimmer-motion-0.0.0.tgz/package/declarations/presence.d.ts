import type Owner from '@ember/owner';
import Component from '@glimmer/component';
import type { PresenceContextProps } from 'motion-dom';
import type { PopMeasurable, PresenceHandle } from './presence-types.ts';
/**
 * AnimatePresence for Glimmer — the same algorithm as Motion's
 * components/AnimatePresence (diff present vs rendered, keep leavers until
 * every exit inside them completes, `exitComplete` map, mode="wait", custom,
 * onExitComplete, propagate).
 *
 *   <Presence @items={{this.crumbs}} @key={{this.keyOf}} @mode="popLayout" as |crumb p|>
 *     <span {{motion presence=p initial=… animate=… exit=…}}>…</span>
 *   </Presence>
 *
 * Motion elements nested deeper inside a child inherit its presence through
 * their parent VisualElement, as React's PresenceContext would provide it.
 */
interface Signature<T> {
    Args: {
        anchorX?: 'left' | 'right';
        anchorY?: 'top' | 'bottom';
        custom?: unknown;
        initial?: boolean;
        items: T[];
        key: (item: T) => string;
        mode?: 'sync' | 'wait' | 'popLayout';
        onExitComplete?: () => void;
        parent?: PresenceHandle;
        /** nested presence: exit with the parent handle when it leaves */
        propagate?: boolean;
    };
    Blocks: {
        default: [T, PresenceHandle];
    };
}
/** PresenceChild: one context per rendered child, tracking the motion elements registered inside it */
declare class Entry<T> implements PresenceHandle {
    item: T;
    /** last presence seen by the diff — plain state, never read during render tracking */
    wasPresent: boolean;
    readonly id: string;
    private children;
    private subscribers;
    /** popLayout: the direct children, so they can be measured before the DOM changes */
    private popCandidates;
    subscribe(refresh: () => void): () => boolean;
    popCandidate(node: PopMeasurable): () => void;
    readonly key: string;
    private owner;
    readonly initialBlocked: boolean;
    constructor(key: string, item: T, owner: Presence<T>, initialBlocked: boolean);
    /** derived from @items (and the parent handle) — nothing is mutated during render */
    get isPresent(): boolean;
    get mode(): "wait" | "sync" | "popLayout";
    get anchorX(): "left" | "right";
    get anchorY(): "bottom" | "top";
    get context(): PresenceContextProps;
    /** presence flipped (PresenceChild's isPresent effects): children report again; no children → done at once */
    presenceChanged(present: boolean): void;
    notify(): void;
    /** every registered child has reported: the leaver is done */
    checkComplete(): void;
    checkImmediateExit(): void;
}
export declare class Presence<T> extends Component<Signature<T>> {
    private entries;
    private order;
    private lastItems?;
    private firstRender;
    /** React's exitComplete map + exitingComponents set */
    private exitComplete;
    private exiting;
    private pendingItems;
    private registeredWithParent?;
    private readonly selfId;
    private version;
    constructor(owner: Owner, args: Signature<T>['Args']);
    get parentPresent(): boolean;
    /** the keys @items currently asks for (empty while a propagating parent is leaving) */
    get presentKeys(): string[];
    isKeyPresent(key: string): boolean;
    get rendered(): Entry<T>[];
    private lastParentPresent?;
    /** AnimatePresence's onExit for one child: once every exiting child is done, show what's pending */
    onExit(key: string): void;
    private safeToRemove;
}
export default Presence;
//# sourceMappingURL=presence.d.ts.map