/**
 * The one host hook the engine glue needs: "run this after the current render pass has committed to the
 * DOM" — React's useEffect slot. The Ember adapter ({{motion}}) installs the runloop's afterRender; another
 * host (a SES-capsuled renderer, a test) installs its own.
 */
type PostRender = (fn: () => void) => void;
export declare function setPostRender(fn: PostRender): void;
export declare function postRender(fn: () => void): void;
export {};
//# sourceMappingURL=scheduler.d.ts.map