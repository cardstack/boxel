import type { VisualElement } from 'motion-dom';
import { Feature } from 'motion-dom';
import { VisualElementDragControls } from './visual-element-drag-controls.ts';
export declare class DragGesture extends Feature<HTMLElement> {
    controls: VisualElementDragControls;
    removeGroupControls: Function;
    removeListeners: Function;
    constructor(node: VisualElement<HTMLElement>);
    mount(): void;
    update(): void;
    unmount(): void;
}
//# sourceMappingURL=drag-gesture.d.ts.map