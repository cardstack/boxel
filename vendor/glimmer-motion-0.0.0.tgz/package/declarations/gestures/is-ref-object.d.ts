export interface MutableRefObject<T> {
    current: T;
}
export declare function isRefObject<E = any>(ref: any): ref is MutableRefObject<E>;
//# sourceMappingURL=is-ref-object.d.ts.map