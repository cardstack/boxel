import type { EventInfo } from 'motion-dom';
export type EventListenerWithPointInfo = (e: PointerEvent, info: EventInfo) => void;
export declare function extractEventInfo(event: PointerEvent): EventInfo;
export declare const addPointerInfo: (handler: EventListenerWithPointInfo) => EventListener;
//# sourceMappingURL=event-info.d.ts.map