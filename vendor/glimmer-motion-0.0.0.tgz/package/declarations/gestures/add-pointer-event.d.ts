import type { EventListenerWithPointInfo } from './event-info.ts';
export declare function addPointerEvent(target: EventTarget, eventName: string, handler: EventListenerWithPointInfo, options?: AddEventListenerOptions): () => void;
//# sourceMappingURL=add-pointer-event.d.ts.map