import { Feature } from 'motion-dom';
export declare class InViewFeature extends Feature<Element> {
    private hasEnteredView;
    private isInView;
    private stopObserver?;
    private startObserver;
    mount(): void;
    update(): void;
    unmount(): void;
}
//# sourceMappingURL=viewport.d.ts.map