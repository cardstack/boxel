import type { VisualElement } from 'motion-dom';
export declare const getContextWindow: ({ current }: VisualElement<Element>) => (Window & typeof globalThis) | null;
//# sourceMappingURL=get-context-window.d.ts.map