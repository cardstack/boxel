import { Feature } from 'motion-dom';
export declare class PressGesture extends Feature<Element> {
    mount(): void;
    unmount(): void;
}
//# sourceMappingURL=press.d.ts.map