import type { PanHandler } from 'motion-dom';
import type { TransformPoint } from 'motion-utils';
interface PanSessionHandlers {
    onEnd: PanHandler;
    onMove: PanHandler;
    onSessionEnd: PanHandler;
    onSessionStart: PanHandler;
    onStart: PanHandler;
    resumeAnimation: () => void;
}
interface PanSessionOptions {
    contextWindow?: (Window & typeof globalThis) | null;
    distanceThreshold?: number;
    dragSnapToOrigin?: boolean | 'x' | 'y';
    /**
     * Element being dragged. When provided, scroll events on its
     * ancestors and window are compensated so the gesture continues
     * smoothly during scroll.
     */
    element?: HTMLElement | null;
    transformPagePoint?: TransformPoint;
}
/**
 * @internal
 */
export declare class PanSession {
    /**
     * @internal
     */
    private history;
    /**
     * @internal
     */
    private startEvent;
    /**
     * @internal
     */
    private lastMoveEvent;
    /**
     * @internal
     */
    private lastMoveEventInfo;
    /**
     * Raw (untransformed) event info, re-transformed each frame
     * so transformPagePoint sees the current parent matrix.
     * @internal
     */
    private lastRawMoveEventInfo;
    /**
     * @internal
     */
    private transformPagePoint?;
    /**
     * @internal
     */
    private handlers;
    /**
     * @internal
     */
    private removeListeners;
    /**
     * For determining if an animation should resume after it is interupted
     *
     * @internal
     */
    private dragSnapToOrigin;
    /**
     * The distance after which panning should start.
     *
     * @internal
     */
    private distanceThreshold;
    /**
     * @internal
     */
    private contextWindow;
    /**
     * Scroll positions of scrollable ancestors and window.
     * @internal
     */
    private scrollPositions;
    /**
     * Cleanup function for scroll listeners.
     * @internal
     */
    private removeScrollListeners;
    constructor(event: PointerEvent, handlers: Partial<PanSessionHandlers>, { transformPagePoint, contextWindow, dragSnapToOrigin, distanceThreshold, element, }?: PanSessionOptions);
    /**
     * Start tracking scroll on ancestors and window.
     */
    private startScrollTracking;
    private onElementScroll;
    private onWindowScroll;
    /**
     * Handle scroll compensation during drag.
     *
     * For element scroll: adjusts history origin since pageX/pageY doesn't change.
     * For window scroll: adjusts lastMoveEventInfo since pageX/pageY would change.
     */
    private handleScroll;
    private updatePoint;
    private handlePointerMove;
    private handlePointerUp;
    updateHandlers(handlers: Partial<PanSessionHandlers>): void;
    end(): void;
}
export {};
//# sourceMappingURL=pan-session.d.ts.map