import type { MotionNodeOptions, PanInfo, VisualElement } from 'motion-dom';
type MotionProps = MotionNodeOptions & {
    _dragX?: any;
    _dragY?: any;
    dragListener?: boolean;
};
export declare const elementDragControls: WeakMap<VisualElement<unknown, unknown, {}>, VisualElementDragControls>;
export interface DragControlOptions {
    /**
     * This distance after which dragging starts and a direction is locked in.
     *
     * @public
     */
    distanceThreshold?: number;
    /**
     * Whether to immediately snap to the cursor when dragging starts.
     *
     * @public
     */
    snapToCursor?: boolean;
}
export declare class VisualElementDragControls {
    private visualElement;
    private panSession?;
    private openDragLock;
    isDragging: boolean;
    private currentDirection;
    private originPoint;
    /**
     * The permitted boundaries of travel, in pixels.
     */
    private constraints;
    private hasMutatedConstraints;
    /**
     * The per-axis resolved elastic values.
     */
    private elastic;
    /**
     * The latest pointer event. Used as fallback when the `cancel` and `stop` functions are called without arguments.
     */
    private latestPointerEvent;
    /**
     * The latest pan info. Used as fallback when the `cancel` and `stop` functions are called without arguments.
     */
    private latestPanInfo;
    /**
     * True while a pan session has locked document text selection.
     */
    private selectLocked;
    constructor(visualElement: VisualElement<HTMLElement>);
    start(originEvent: PointerEvent, { snapToCursor, distanceThreshold }?: DragControlOptions): void;
    /**
     * @internal
     */
    stop(event?: PointerEvent, panInfo?: PanInfo): void;
    /**
     * @internal
     */
    cancel(): void;
    /**
     * Clean up the pan session without modifying other drag state.
     * This is used during unmount to ensure event listeners are removed
     * without affecting projection animations or drag locks.
     * @internal
     */
    endPanSession(): void;
    private lockSelect;
    private unlockSelect;
    private updateAxis;
    private resolveConstraints;
    private resolveRefConstraints;
    private startAnimation;
    private startAxisValueAnimation;
    private stopAnimation;
    /**
     * Drag works differently depending on which props are provided.
     *
     * - If _dragX and _dragY are provided, we output the gesture delta directly to those motion values.
     * - Otherwise, we apply the delta to the x/y motion values.
     */
    private getAxisMotionValue;
    private snapToCursor;
    /**
     * When the viewport resizes we want to check if the measured constraints
     * have changed and, if so, reposition the element within those new constraints
     * relative to where it was before the resize.
     */
    scalePositionWithinConstraints(): void;
    addListeners(): (() => void) | undefined;
    getProps(): MotionProps;
}
export declare function expectsResolvedDragConstraints({ dragConstraints, onMeasureDragConstraints, }: MotionProps): boolean;
export {};
//# sourceMappingURL=visual-element-drag-controls.d.ts.map