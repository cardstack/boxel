import { Feature } from 'motion-dom';
export declare class HoverGesture extends Feature<Element> {
    mount(): void;
    unmount(): void;
}
//# sourceMappingURL=hover.d.ts.map