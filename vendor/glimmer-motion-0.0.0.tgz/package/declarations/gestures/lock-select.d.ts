export declare function lockTextSelect(): void;
export declare function unlockTextSelect(): void;
//# sourceMappingURL=lock-select.d.ts.map