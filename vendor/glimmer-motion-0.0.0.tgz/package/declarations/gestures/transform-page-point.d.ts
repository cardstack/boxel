/**
 * Motion's correctParentTransform / transformViewBoxPoint (utils/transform-rotated-parent.ts,
 * utils/transform-viewbox-point.ts), with the React ref replaced by an element or a {current} ref.
 */
type Point = {
    x: number;
    y: number;
};
type TransformPoint = (p: Point) => Point;
type Ref<T> = T | {
    current: T | null;
} | null | undefined;
/** pointer coordinates corrected for a parent with a CSS transform (rotation, scale, skew) */
export declare function correctParentTransform(parentRef: Ref<Element>): TransformPoint;
/** pointer coordinates scaled into an <svg>'s viewBox coordinate system */
export declare function transformViewBoxPoint(svgRef: Ref<SVGSVGElement>): TransformPoint;
export {};
//# sourceMappingURL=transform-page-point.d.ts.map