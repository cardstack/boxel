import type { Point } from 'motion-utils';
export declare const distance: (a: number, b: number) => number;
export declare function distance2D(a: Point, b: Point): number;
//# sourceMappingURL=distance.d.ts.map