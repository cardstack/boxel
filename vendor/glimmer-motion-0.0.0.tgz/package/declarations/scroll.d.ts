import { type FunctionBasedModifier } from 'ember-modifier';
import { type MotionValue } from 'motion-dom';
import type { ScrollInfoOptions } from './dom/scroll/types.ts';
import { type InViewOptions } from './dom/viewport.ts';
export type UseScrollOptions = Omit<ScrollInfoOptions, 'container' | 'target'>;
/** a modifier with no arguments: `<div {{s.container}}>` */
export type ElementModifier = FunctionBasedModifier<{
    Args: {
        Named: Record<string, never>;
        Positional: [];
    };
    Element: Element;
}>;
export interface ScrollValues {
    /** the scrollable element (default: the document) */
    container: ElementModifier;
    scrollX: MotionValue<number>;
    scrollXProgress: MotionValue<number>;
    scrollY: MotionValue<number>;
    scrollYProgress: MotionValue<number>;
    start(): void;
    stop(): void;
    /** the element whose position within the container is tracked */
    target: ElementModifier;
    /** track the document scroll without a container or target — place it anywhere that lives as long as the values */
    track: ElementModifier;
}
export declare function scrollProgress(options?: UseScrollOptions): ScrollValues;
export interface UseInViewOptions extends Omit<InViewOptions, 'root'> {
    initial?: boolean;
    once?: boolean;
    root?: Element | Document | {
        current: Element | null;
    };
}
export declare class InView {
    isInView: boolean;
    private options;
    constructor(options?: UseInViewOptions);
    observe: ElementModifier;
}
/** @deprecated React's name for it. Use `scrollProgress()`. */
export declare const useScroll: typeof scrollProgress;
/** @deprecated React's name for it. Use `new InView(options)`. */
export declare const useInView: (options?: UseInViewOptions) => InView;
//# sourceMappingURL=scroll.d.ts.map