export { isMotionIdle, whatIsBusy } from '../activity.ts';
export interface Box {
    height: number;
    left: number;
    top: number;
    width: number;
}
/**
 * getBoundingClientRect(), relative to `#ember-testing`.
 *
 * Ember Animated's `bounds()`, and for the same reason: the container is not
 * at the page origin and QUnit is free to move it.
 */
export declare function bounds(element: Element): Box;
/**
 * The linear part of every transform between this element and the document —
 * a 2×2 matrix, which is the element's shape.
 *
 * A layout animation distorts by scale, and a scale a parent applied is
 * invisible in the child's own `style.transform`. This is what a test asserts
 * on when the question is "did the label get stretched", which no amount of
 * reading `x` will answer.
 */
export declare function shape(element: Element): {
    a: number;
    b: number;
    c: number;
    d: number;
};
export declare function boundsAndShape(element: Element): Box & ReturnType<typeof shape>;
export interface SettleOptions {
    /** give up after this long and report what was still moving (default 5000) */
    timeout?: number;
}
/**
 * Resolve when every motion element, layout animation and <Choreo> timeline in
 * the document has stopped.
 *
 * Idle is required on two consecutive checks, not one. A value clears its
 * animation in a microtask after it resolves, and a Choreo row that ends
 * commonly unmounts a leaver — which is a render, which is another pass. One
 * check would catch the gap between those and call it settled.
 */
export declare function animationsSettled({ timeout, }?: SettleOptions): Promise<void>;
/** open every parked gate and settle the segment it releases */
export declare function advanceGate(): Promise<void>;
/** set every live run's clock, in seconds — a scrubbed still */
export declare function seekTo(seconds: number): Promise<void>;
/** how fast an element is moving, in px/s, sampled across two frames */
export declare function velocityOf(el: HTMLElement): Promise<{
    x: number;
    y: number;
}>;
/** how many leavers are parked in a <Choreo> orphan layer right now */
export declare function orphanCount(root?: HTMLElement): number;
/**
 * The first LIVE match for `selector` — the copy that is still part of the
 * rendered tree, never a leaver parked in a region's orphan layer.
 *
 * Mid-crossing an identity exists twice: the arriving element in the live
 * tree, and the departing skin the region locked into `[data-choreo-orphans]`
 * so it can be flown and faded. That layer is the region's FIRST child, so a
 * bare `querySelector` answers with the ghost — an element whose component
 * has already been torn down, whose listeners are gone, and whose box is
 * where the OLD scene stood. Clicking it does nothing; measuring it measures
 * the past. Neither failure names itself.
 *
 * So any assertion or interaction a test performs while a crossing may be
 * aloft should come through here. A raised sprite (`c.Raise`) is deliberately
 * still live: it is the real element on a different layer, not a copy.
 */
export declare function live<E extends Element = HTMLElement>(selector: string, root?: ParentNode): E | null;
/** every live match for `selector`, in document order — see `live()` */
export declare function liveAll<E extends Element = HTMLElement>(selector: string, root?: ParentNode): E[];
export declare function strandedTransforms(root?: HTMLElement): string[];
/**
 * Reset the state that outlives an owner.
 *
 * The beacon registry, the far-match barrier and the projection root are one
 * per document by design — a beacon in the chrome has to be visible to a region
 * in an outlet, and the barrier exists to see across regions. That is right for
 * an app and a leak between tests: a torn-down element still holding the name
 * "trash" wins the first-registration race against the next test's real one.
 */
export declare function setupMotion(hooks: {
    afterEach(fn: (assert?: LoopAssert) => void): void;
    beforeEach(fn: () => void): void;
}): void;
/** the sliver of QUnit's assert this module uses, so test-support needs no QUnit types */
interface LoopAssert {
    ok?: (state: boolean, message?: string) => void;
}
export declare function resetMotion(): void;
//# sourceMappingURL=index.d.ts.map