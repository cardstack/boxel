/**
 * The layout handshake React does in getSnapshotBeforeUpdate / componentDidUpdate:
 * every projecting node snapshots itself BEFORE the DOM changes, and the root
 * measures AFTER. In Glimmer we wrap the state mutation that causes the change.
 *
 *   layoutChange(() => { this.items = next; });
 */
import type { IProjectionNode } from 'motion-dom';
export declare let hasTakenAnySnapshot: boolean;
export declare function registerProjection(node: IProjectionNode): () => boolean;
export declare function snapshotAll(): void;
export declare function setMountFlusher(fn: () => void): void;
/**
 * Did the breaker trip since it was last reset?
 *
 * Nothing in an application should need this. It is here for test support: a
 * layout loop is always a bug, and a suite that can see one is a suite that
 * can fail on it by name instead of timing out with no stack.
 */
export declare function layoutLoopDetected(): boolean;
export declare function resetLayoutLoopGuard(): void;
/**
 * React's componentDidUpdate timing: every projection root's didUpdate() runs once per render pass, after
 * render and after every element rendered in the pass has mounted. The engine's update then happens in a
 * microtask after that — never between Glimmer's render and the mounts.
 */
export declare function requestSettle(): void;
/** run after this pass has settled (mounts + didUpdate), in the engine's post-render microtask —
 *  React's componentDidUpdate → microtask.postRender slot */
export declare function afterSettle(fn: () => void): void;
export declare function settleAll(): void;
export declare function layoutChange<T>(fn: () => T): T;
/**
 * Motion's useInstantLayoutTransition(): run a state change without layout animation —
 * the root blocks the next update so no projection animates.
 */
export declare function instantLayoutTransition(callback?: () => void): void;
//# sourceMappingURL=layout.d.ts.map