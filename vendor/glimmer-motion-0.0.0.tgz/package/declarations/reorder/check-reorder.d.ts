import type { Point } from 'motion-utils';
import type { ItemData, ReorderAxis } from './types.ts';
export declare function checkReorder<T>(order: ItemData<T>[], value: T, offset: Point, velocity: Point, axis: ReorderAxis, direction?: 'ltr' | 'rtl'): ItemData<T>[];
//# sourceMappingURL=check-reorder.d.ts.map