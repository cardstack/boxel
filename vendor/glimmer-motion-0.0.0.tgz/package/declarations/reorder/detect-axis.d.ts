import type { Box } from 'motion-utils';
import type { ReorderAxis } from './types.ts';
export declare function detectAxis(layouts: Box[]): ReorderAxis;
//# sourceMappingURL=detect-axis.d.ts.map