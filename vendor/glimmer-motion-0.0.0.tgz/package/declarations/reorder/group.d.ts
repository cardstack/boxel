/**
 * Reorder.Group for Glimmer — Motion's packages/framer-motion/src/components/Reorder/Group.tsx.
 * Renders a <ul> (or `@tag`) and yields the reorder context the items take as `@group`:
 *
 *   <ReorderGroup @values={{this.items}} @onReorder={{this.setItems}} @axis="x" as |group|>
 *     {{#each this.items as |item|}}<ReorderItem @group={{group}} @value={{item}}>…</ReorderItem>{{/each}}
 *   </ReorderGroup>
 */
import Component from '@glimmer/component';
import type { Transition } from 'motion-dom';
import type { Box, Point } from 'motion-utils';
import type { ReorderAxis, ReorderContextProps } from './types.ts';
interface Signature<V> {
    Args: {
        /** detected from the item layout by default; "xy" enables wrapped-layout reordering */
        axis?: ReorderAxis;
        layout?: boolean | 'position' | 'size';
        onReorder: (newOrder: V[]) => void;
        style?: Record<string, unknown>;
        transition?: Transition;
        values: V[];
    };
    Blocks: {
        default: [group: ReorderContextProps<V>];
    };
    Element: HTMLElement;
}
export declare class ReorderGroup<V> extends Component<Signature<V>> {
    itemLayouts: Map<V, Box>;
    detectedAxis: ReorderAxis;
    isReordering: boolean;
    groupRef: {
        current: Element | null;
    };
    get axis(): ReorderAxis;
    /** disable browser scroll anchoring: reordering would otherwise shift the scroll position mid-drag */
    get style(): {
        overflowAnchor: string;
    };
    /** React: every render prunes layouts of values no longer present */
    private prune;
    registerItem: (value: V, layout: Box) => void;
    updateOrder: (item: V, offset: Point, velocity: Point) => void;
    get context(): ReorderContextProps<V>;
    /** React's Reorder.Group re-renders every item on reorder, so each snapshots its layout before the
     *  DOM moves — that snapshot is what lets the projection keep the dragged item under the pointer */
    get renderDetector(): undefined;
}
export default ReorderGroup;
//# sourceMappingURL=group.d.ts.map