export declare function resetAutoScrollState(): void;
export declare function autoScrollIfNeeded(groupElement: Element | null, pointerPosition: number, axis: 'x' | 'y', velocity: number): void;
//# sourceMappingURL=auto-scroll.d.ts.map