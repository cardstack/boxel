/**
 * Reorder.Item for Glimmer — Motion's packages/framer-motion/src/components/Reorder/Item.tsx.
 * Renders an <li> that is a draggable, layout-animated motion element snapping back to origin;
 * while it is dragged it reports its offset to the group, which reorders the values.
 */
import Component from '@glimmer/component';
import { type MotionNodeOptions, type MotionValue, type Transition } from 'motion-dom';
import type { PresenceHandle } from '../presence-types.ts';
import type { ReorderContextProps } from './types.ts';
type DragInfo = {
    delta: {
        x: number;
        y: number;
    };
    offset: {
        x: number;
        y: number;
    };
    point: {
        x: number;
        y: number;
    };
    velocity: {
        x: number;
        y: number;
    };
};
interface Signature<V> {
    Args: {
        animate?: MotionNodeOptions['animate'];
        dragControls?: MotionNodeOptions['dragControls'];
        dragListener?: boolean;
        dragTransition?: MotionNodeOptions['dragTransition'];
        exit?: MotionNodeOptions['exit'];
        group: ReorderContextProps<V>;
        initial?: MotionNodeOptions['initial'];
        /** a subset of layout options, primarily to disable layout="size" */
        layout?: true | 'position';
        onDrag?: (event: PointerEvent, info: DragInfo) => void;
        onDragEnd?: (event: PointerEvent, info: DragInfo) => void;
        presence?: PresenceHandle;
        style?: Record<string, unknown>;
        transition?: Transition;
        value: V;
        whileDrag?: MotionNodeOptions['whileDrag'];
    };
    Blocks: {
        default: [];
    };
    Element: HTMLElement;
}
export declare class ReorderItem<V> extends Component<Signature<V>> {
    point: {
        x: MotionValue<number>;
        y: MotionValue<number>;
    };
    zIndex: MotionValue<1 | "unset">;
    get style(): {
        x: MotionValue<number>;
        y: MotionValue<number>;
        zIndex: MotionValue<1 | "unset">;
    };
    get layout(): true | 'position';
    get dragAxis(): true | 'x' | 'y';
    onDrag: (event: PointerEvent, info: DragInfo) => void;
    onDragEnd: (event: PointerEvent, info: DragInfo) => void;
    onLayoutMeasure: (measured: Parameters<ReorderContextProps<V>["registerItem"]>[1]) => void;
}
export default ReorderItem;
//# sourceMappingURL=item.d.ts.map