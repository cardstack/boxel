/** React's ref on the group element */
export declare const captureGroup: import("ember-modifier").FunctionBasedModifier<{
    Args: {
        Positional: [{
            current: Element | null;
        }];
        Named: import("ember-modifier/-private/signature").EmptyObject;
    };
    Element: Element;
}>;
//# sourceMappingURL=capture.d.ts.map