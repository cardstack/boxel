/** a number written into `style`, the way React would write it */
export declare const styleValue: (key: string, value: number | string) => string;
//# sourceMappingURL=unitless.d.ts.map