import type { ScrollInfo } from './types.ts';
export declare const createScrollInfo: () => ScrollInfo;
export declare function updateScrollInfo(element: Element, info: ScrollInfo, time: number): void;
//# sourceMappingURL=info.d.ts.map