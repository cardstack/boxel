import type { AnimationPlaybackControls } from 'motion-dom';
import type { ScrollOptionsWithDefaults } from './types.ts';
export declare function attachToAnimation(animation: AnimationPlaybackControls, options: ScrollOptionsWithDefaults): VoidFunction;
//# sourceMappingURL=attach-animation.d.ts.map