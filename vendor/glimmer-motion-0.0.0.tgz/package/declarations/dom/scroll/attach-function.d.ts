import type { OnScroll, ScrollOptionsWithDefaults } from './types.ts';
export declare function attachToFunction(onScroll: OnScroll, options: ScrollOptionsWithDefaults): VoidFunction;
//# sourceMappingURL=attach-function.d.ts.map