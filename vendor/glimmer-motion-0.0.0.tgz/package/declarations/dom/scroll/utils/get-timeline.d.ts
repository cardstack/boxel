import type { ProgressTimeline } from 'motion-dom';
import type { ScrollOptionsWithDefaults } from '../types.ts';
export declare function getTimeline({ source, container, ...options }: ScrollOptionsWithDefaults): ProgressTimeline;
//# sourceMappingURL=get-timeline.d.ts.map