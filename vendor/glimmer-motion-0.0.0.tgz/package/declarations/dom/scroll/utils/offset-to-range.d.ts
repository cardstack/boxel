import type { ScrollOffset } from '../types.ts';
interface ViewTimelineRange {
    rangeEnd: string;
    rangeStart: string;
}
export declare function offsetToViewTimelineRange(offset?: ScrollOffset): ViewTimelineRange | undefined;
export {};
//# sourceMappingURL=offset-to-range.d.ts.map