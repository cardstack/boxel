export declare function canUseNativeTimeline(target?: Element): boolean;
//# sourceMappingURL=can-use-native-timeline.d.ts.map