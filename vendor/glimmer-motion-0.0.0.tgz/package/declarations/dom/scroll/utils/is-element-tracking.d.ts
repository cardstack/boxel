import type { ScrollOptionsWithDefaults } from '../types.ts';
/**
 * Currently, we only support element tracking with `scrollInfo`, though in
 * the future we can also offer ViewTimeline support.
 */
export declare function isElementTracking(options?: ScrollOptionsWithDefaults): Element | import("../types.ts").ScrollOffset | undefined;
//# sourceMappingURL=is-element-tracking.d.ts.map