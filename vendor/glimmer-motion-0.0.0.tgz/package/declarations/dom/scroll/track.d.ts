import type { OnScrollInfo, ScrollInfoOptions } from './types.ts';
export type ScrollTargets = Array<HTMLElement>;
export declare function scrollInfo(onScroll: OnScrollInfo, { container, trackContentSize, ...options }?: ScrollInfoOptions): VoidFunction;
//# sourceMappingURL=track.d.ts.map