import type { ProgressIntersection } from '../types.ts';
export declare const ScrollOffset: Record<string, ProgressIntersection[]>;
//# sourceMappingURL=presets.d.ts.map