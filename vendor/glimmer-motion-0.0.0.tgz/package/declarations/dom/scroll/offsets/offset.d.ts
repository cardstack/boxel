import type { Edge, Intersection, ProgressIntersection } from '../types.ts';
export declare function resolveOffset(offset: Edge | Intersection | ProgressIntersection, containerLength: number, targetLength: number, targetInset: number): number;
//# sourceMappingURL=offset.d.ts.map