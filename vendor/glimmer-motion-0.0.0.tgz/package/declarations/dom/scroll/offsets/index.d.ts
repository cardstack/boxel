import type { ScrollInfo, ScrollInfoOptions } from '../types.ts';
export declare function resolveOffsets(container: Element, info: ScrollInfo, options: ScrollInfoOptions): void;
//# sourceMappingURL=index.d.ts.map