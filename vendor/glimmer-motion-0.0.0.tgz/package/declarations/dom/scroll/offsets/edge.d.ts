import type { Edge, NamedEdges } from '../types.ts';
export declare const namedEdges: Record<NamedEdges, number>;
export declare function resolveEdge(edge: Edge, length: number, inset?: number): number;
//# sourceMappingURL=edge.d.ts.map