import type { AnimationPlaybackControls } from 'motion-dom';
import type { OnScroll, ScrollOptions } from './types.ts';
export declare function scroll(onScroll: OnScroll | AnimationPlaybackControls, { axis, container, ...options }?: ScrollOptions): VoidFunction;
//# sourceMappingURL=index.d.ts.map