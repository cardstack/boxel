import type { OnScrollHandler, OnScrollInfo, ScrollInfo, ScrollInfoOptions } from './types.ts';
export declare function createOnScrollHandler(element: Element, onScroll: OnScrollInfo, info: ScrollInfo, options?: ScrollInfoOptions): OnScrollHandler;
//# sourceMappingURL=on-scroll-handler.d.ts.map