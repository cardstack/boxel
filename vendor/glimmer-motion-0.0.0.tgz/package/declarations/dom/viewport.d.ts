import type { ElementOrSelector } from 'motion-dom';
export type ViewChangeHandler = (entry: IntersectionObserverEntry) => void;
type MarginValue = `${number}${'px' | '%'}`;
type MarginType = MarginValue | `${MarginValue} ${MarginValue}` | `${MarginValue} ${MarginValue} ${MarginValue}` | `${MarginValue} ${MarginValue} ${MarginValue} ${MarginValue}`;
export interface InViewOptions {
    amount?: 'some' | 'all' | number;
    margin?: MarginType;
    root?: Element | Document;
}
export declare function inView(elementOrSelector: ElementOrSelector, onStart: (element: Element, entry: IntersectionObserverEntry) => void | ViewChangeHandler, { root, margin: rootMargin, amount }?: InViewOptions): VoidFunction;
export {};
//# sourceMappingURL=viewport.d.ts.map