import Component from '@glimmer/component';
import type { Beat, ElementModifier } from './types.ts';
export interface PlateSignature {
    Args: {
        /** the beat being set */
        beat: Beat;
        /** the chapter's numeral, set enormous behind a plate */
        chapterN: string;
        /** `--cf-glyphs`: how many characters the word is, for the column's size */
        glyphFit: string;
        /** 'is-latin' | 'is-tall' | '' — the script's own setting */
        glyphTone: string;
        /** the film's own handle on the block, for the parallax and the fade */
        mount: ElementModifier;
        /** one pass behind the boot: content mounts on this so its entrance is a real insertion */
        rolling: boolean;
        /** when each of up to four phrases lands, seconds into the beat */
        sayAt: number[];
        /** when the kicker, the word and the reading land, seconds into the beat */
        typeAt: number[];
    };
}
/**
 * THE FRONT LAYER — the lower third, the title, the plate and the point,
 * which are one component set four ways. Keyed on the beat, so every
 * hand-off replays the delivery: the kicker rises, the word lands
 * centre-out on an overshoot, the reading and the gloss follow, and the
 * phrases arrive one by one against the measured read. A beat change
 * drops the old type in one quick fall. All of it is score vocabulary.
 *
 * Each row is a PLANE, and the nesting is load-bearing: the wrapper is
 * the plane and the film's loop drifts it, the paragraph inside is the
 * type and Motion delivers it. One writer each.
 */
export declare class Plate extends Component<PlateSignature> {
}
//# sourceMappingURL=plate.d.ts.map