import Component from '@glimmer/component';
import type { Chapter } from './types.ts';
/** a chapter as a door on the rule */
export interface RailMark {
    /** where on the rule, 0..1 */
    at: number;
    done: boolean;
    head: number;
    here: boolean;
    /** the label the door announces when the rule is a clock */
    label?: string;
    n: string;
    title: string;
}
export interface RailSignature {
    Args: {
        /** the chapter on screen */
        chapter: Chapter;
        /** the ends of the rule, as the film writes them; empty when the rule is time */
        labels?: [string, string];
        marks: RailMark[];
        /** cut to a chapter's head */
        pick: (head: number) => void;
        /** the readout riding the head — the year, or nothing */
        readout?: string;
    };
}
/**
 * THE FILM ON ONE LINE. A rule the width of the chapter strip, the run
 * so far filled in the accent, a dot on the head and the readout riding
 * it; the chapters are dots at the places they open, so the distance
 * between them is a fact and not a layout. The dots are the doors into
 * the chapters. The head's position is a custom property (`--cf-head`)
 * written by the film every frame, so nothing here re-renders on the
 * clock.
 */
export declare class Rail extends Component<RailSignature> {
    atStyle: (m: RailMark) => string;
}
//# sourceMappingURL=rail.d.ts.map