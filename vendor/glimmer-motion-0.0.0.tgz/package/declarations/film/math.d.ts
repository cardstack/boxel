/** the small arithmetic every film does: the same four lines, once */
export declare const RAD: number;
export declare const lerp: (a: number, b: number, t: number) => number;
export declare const clamp01: (v: number) => number;
/** smoothstep on [0,1] */
export declare const smooth: (t: number) => number;
export declare const hex: (h: string) => [number, number, number];
/** relative luminance of a #rrggbb, 0..1 */
export declare const luminance: (h: string) => number;
/** a #rrggbb at an alpha, as CSS */
export declare const rgba: (h: string, a: number) => string;
export declare const mmss: (s: number) => string;
/** the shortest way round a circle, radians */
export declare const wrapAngle: (d: number) => number;
//# sourceMappingURL=math.d.ts.map