/**
 * THE JOINS, as presentations.
 *
 * A join is what happens to the OUTGOING frame while the incoming shot
 * plays underneath it from its very first frame: the still is swept off,
 * thinned, closed in a circle, covered with a colour. That is one
 * contract — a component given the still and told how long it has — and
 * the film's twelve seams are twelve components that satisfy it. A
 * thirteenth, written in an app, satisfies it the same way and is named
 * from a shot's `<f.Join @presentation={{MyWipe}} />`; the film learns
 * nothing about it but its length.
 *
 * Three of the twelve are not presentations at all: a `cut` and a
 * `whip` are the camera's, a `sweep` is the light's, and the film plays
 * those itself. Three more — `blend`, `melt`, `dip` — the picture can
 * do in its own glass (`Picture.dissolve`) and only fall back to a still
 * here when it cannot.
 *
 * A seam that never ends is a lid: every overlay retires itself when its
 * animation ends, and a seekable one (stood at a time by an exact film)
 * is taken off by the film instead.
 */
import Component from '@glimmer/component';
import type { Join, JoinName, Over } from './types.ts';
export declare const retire: import("ember-modifier").FunctionBasedModifier<{
    Args: {
        Positional: [boolean | undefined];
        Named: import("ember-modifier/-private/signature").EmptyObject;
    };
    Element: HTMLElement;
}>;
/** what a presentation is given */
export interface PresentationSignature {
    Args: {
        /** where the seam is aimed, as inline custom properties (an iris's centre) */
        at?: string;
        /** the colour a dip passes through */
        color?: string;
        /** the film stands the overlay at a time itself: never retire on `animationend` */
        seekable?: boolean;
        /** the outgoing frame, as a data URL; empty when the picture held it in its own glass */
        still: string;
    };
}
/** a presentation is a Glimmer component class on the contract above — the class, not a `ComponentLike`, so an app's and the library's typings agree */
export type PresentationComponent = typeof Component<PresentationSignature>;
/** a seam the film can play: its presentation, how long it holds the picture, whether it needs a still */
export interface Presentation {
    /** the overlay; none for a seam the camera or the light plays */
    component?: PresentationComponent;
    /**
     * How deep this seam goes by default, when the score does not say
     * (`Over`). A presentation an app brings may want `everything` — a
     * curtain that drops in front of the picture and leaves the caption
     * standing in front of it is not a curtain.
     */
    over?: Over;
    /** seconds the seam holds the picture */
    secs: number;
    /** the seam paints a still of the outgoing frame over the incoming one */
    still: boolean;
}
/** the outgoing frame itself, swept off along the sun's diagonal behind a feathered edge */
export declare class Wipe extends Component<PresentationSignature> {
}
/** the long soft one, no push and no colour */
export declare class Melt extends Component<PresentationSignature> {
}
/** the outgoing frame held as a still and faded over the live incoming shot */
export declare class Blend extends Component<PresentationSignature> {
}
/** the old shot closes in a circle onto the incoming subject; the centre rides inline custom properties */
export declare class Iris extends Component<PresentationSignature> {
}
/** the still blurs out over the incoming shot; also the freeze half of a rack-defocus */
export declare class Blur extends Component<PresentationSignature> {
}
/** the still dissolves by its own luminance */
export declare class Luma extends Component<PresentationSignature> {
}
/** a white frame, and the picture comes back through it */
export declare class Flash extends Component<PresentationSignature> {
}
/** freeze under, veil over: the old shot holds while the colour closes, the seam passes in the dark, the veil lifts on the new shot */
export declare class Dip extends Component<PresentationSignature> {
    get veil(): string;
}
/**
 * A SEAM AS TWO NUMBERS, at progress `p`.
 *
 * `mix` is how much of the HELD frame is over the live one; `veil` is how
 * much of a colour is over both. The picture composites them in light,
 * and the film reveals the incoming furniture by what is left over —
 * `1 - max(mix, veil)`. One number in, two halves out: that is the whole
 * seam, and it is why a seek through one is free (a function of the
 * clock, with nothing to stand at a time).
 *
 * Only the three the glass can hold are here. A wipe and an iris are
 * SHAPES rather than mixes — they need pixels in the DOM to sweep and to
 * clip — and they keep their presentation.
 */
export declare function seamShape(kind: JoinName, p: number): {
    mix: number;
    veil: number;
};
/** the seams the picture can hold in its own glass, given `Picture.seam` */
export declare function inGlass(kind: JoinName): boolean;
/** the film's own twelve seams, by name */
export declare const PRESENTATIONS: Record<Join, Presentation>;
/** how long each join holds the picture, in seconds */
export declare const JOIN_SECS: Record<string, number>;
/** the joins that hold a still of the outgoing shot over the incoming one */
export declare const STILL_JOINS: ReadonlySet<string>;
export interface JoinsSignature {
    Args: {
        /** the colour a dip passes through */
        dipColor?: string;
        /** the outgoing frame, when the page could not hold it in its own glass */
        freeze?: string;
        /** the iris's centre, as inline custom properties */
        irisAt?: string;
        /** which seam is playing */
        kind: '' | JoinName;
        /** every seam the film knows: the twelve, and any a score brought */
        presentations: Record<string, Presentation>;
        /** the film drives the overlay's clock: it is never retired by its own end */
        seekable?: boolean;
        /**
         * A NEW ELEMENT PER CUT. Keyed on the stamp so each overlay plays from
         * its own first frame; the number only ever goes up.
         */
        stamp: number;
    };
}
/**
 * THE SEAM ON SCREEN: whichever presentation the kind names, given the
 * still, a new element per cut. A seam that needs a still and has none
 * (the picture held it in its own glass) paints nothing here.
 */
export declare class Joins extends Component<JoinsSignature> {
    get presentation(): PresentationComponent | undefined;
}
//# sourceMappingURL=joins.d.ts.map