import type { Beat, Cam, Chapter, Join, JoinName } from './types.ts';
/** one tick of the shot list, in seconds: a beat's `ticks` × this is its length */
export declare const TICK = 2;
/** the whole film, in seconds, leads included */
export declare function totalSecs(beats: Beat[]): number;
/** film seconds before a beat's nominal head, leads included */
export declare function secsBefore(beats: Beat[], index: number): number;
/**
 * FILM SECONDS AT WHICH A BEAT'S OWN SHOT BEGINS. The cues fire one tick
 * after the beat table says, because the pose-in-force seed occupies the
 * spline's first slot — so the windows the exact clock derives carry the
 * same offset, and the picture and the type agree with the cut film to
 * the frame. This is the single most load-bearing constant in the film.
 */
export declare function beatStart(beats: Beat[], i: number): number;
/** one cue per beat (and an `air` cue ahead of a led beat), as delays into the score */
export interface Cue {
    action: 'air' | 'beat';
    delay: number;
    index: string;
}
export declare function cues(beats: Beat[]): Cue[];
/** the first beat of each chapter, in whole-film indices */
export declare function chapterHeads(beats: Beat[]): number[];
/** the chapter menu's rows: head index, numeral, title, shot count, running time */
export interface Content {
    head: number;
    n: string;
    secs: number;
    shots: number;
    title: string;
}
export declare function contents(beats: Beat[], chapters: Chapter[]): Content[];
/** the seam a beat is entered through, or none when it neither cuts nor names one */
export declare function joinInto(beats: Beat[], i: number, defaultJoin: Join): JoinName | null;
/**
 * WHERE A SHOT ENDS — the beat's authored tail, floored so it always reads
 * as a move, and clamped so it never travels past the pose the next shot
 * begins on. Shared by the path (which lerps its waypoints across it) and
 * by the launch: a cut hands the chaser this shot's own speed.
 *
 * A shot must move on screen, not on paper: frame-differencing a capture
 * of the cut showed authored tails of a few degrees reading as stills, so
 * a tail is a DIRECTION and a floor, not a distance — what the beat asks
 * for is honoured, and anything slower than a real slow move is stretched
 * up to one. The floors are per second. And it never travels past where
 * the next shot begins: at a cut that jumped BACKWARDS into the successor.
 */
export declare function tailFor(beats: Beat[], bi: number): Cam;
/** one waypoint of the camera spline, in the terms `c.Camera3D @through` takes */
export interface Waypoint {
    cut?: boolean;
    dolly: number;
    look: {
        x: number;
        y: number;
        z: number;
    };
    pitch: number;
    x: number;
    y: number;
    yaw: number;
}
/**
 * THE PATH. Every beat contributes `ticks` waypoints, lerped from its
 * head to its tail, so waypoint count is screen time; a led beat first
 * contributes `lead` waypoints travelling in from the previous tail; a
 * `cut` beat splices the spline. `recut` marks the first beat as a splice
 * too — a cut film re-cut from a chapter's head has nothing behind it.
 */
export declare function waypoints(beats: Beat[], recut?: boolean): Waypoint[];
/**
 * THE GOLDEN SCHEDULE: one object per film, everything above at once, in
 * the shape the fixtures are written in. A refactor of the engine that
 * changes any number in here has changed the film.
 */
export interface Schedule {
    beats: {
        ch: number;
        id: string;
        join: JoinName | null;
        lead: number;
        secsBefore: number;
        start: number;
        ticks: number;
    }[];
    contents: Content[];
    cues: Cue[];
    total: number;
    waypoints: Waypoint[];
}
export declare function schedule(beats: Beat[], chapters: Chapter[], defaultJoin: Join): Schedule;
//# sourceMappingURL=schedule.d.ts.map