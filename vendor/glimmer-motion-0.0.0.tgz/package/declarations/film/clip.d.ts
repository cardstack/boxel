import Component from '@glimmer/component';
import type { ClipSpec, ClipState } from './clips.ts';
import type { ElementModifier } from './types.ts';
export interface ClipSignature {
    Args: {
        /** the picture, read back, when the clip is a freeze */
        freeze?: string;
        /** a new element per clip window, so the entrance replays */
        key: string;
        /** which lane this clip is on: the film's own handle is per lane */
        lane: number;
        /** the film's handle on the media element, for the per-frame sync */
        mount: ElementModifier<HTMLElement, [number]>;
        spec: ClipSpec;
        /** the resolved source, under `assets` */
        src: string;
        state: ClipState;
    };
}
/**
 * A CLIP ON THE PICTURE. A video, a still or a freeze of the picture
 * itself, standing over the frame for its window — full frame, or as an
 * inset with its caption like the photograph. The media is not played by
 * the browser's own clock: the film writes its source time every frame
 * (a paused element seeked, a playing one corrected), so a clip is where
 * the clock says it is whether the film played there or was scrubbed
 * there. It arrives the way the insert does — wiped in — and leaves in a
 * short fade.
 */
export declare class Clip extends Component<ClipSignature> {
    /** a pip is placed by the score, in percent of the frame */
    get place(): string;
    /** a pip fades; the editorial card is wiped in and out */
    get isPip(): boolean;
    /**
     * THE LOOK THIS CLIP IS WEARING, as a CSS filter — composed in the same
     * order the picture's own shader composes its grade (saturate, then
     * contrast, then brightness, then sepia and hue), because filter order
     * is not commutative and the two should agree about what a number
     * means. Blur goes last, where a lens would put it.
     *
     * It rides the MEDIA, not the figure, so an inset's caption and its card
     * are not graded with the footage.
     */
    get look(): string;
    /** seconds a pip takes to arrive and to go */
    get fade(): number;
    get muted(): boolean;
    get volume(): number;
}
//# sourceMappingURL=clip.d.ts.map