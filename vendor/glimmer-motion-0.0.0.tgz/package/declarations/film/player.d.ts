import Component from '@glimmer/component';
import type { Chapter, ElementModifier } from './types.ts';
/** one chapter as a segment of the scrub bar */
export interface PlaybarSegment {
    head: number;
    n: string;
    style: string;
    title: string;
}
/** what the hand is pointing at on the bar: the chapter and the time */
export interface ScrubTip {
    ch: string;
    t: string;
}
export interface PlayerSignature {
    Args: {
        /** the front door is up: the transport waits outside */
        away: boolean;
        /** which cut of the film this is; shown only under debug */
        build?: string;
        /** toggle captions */
        cc: () => void;
        chapter: Chapter;
        clock: string;
        debug?: boolean;
        duration: string;
        /** the fader moved */
        fade: (e: Event) => void;
        full: boolean;
        hear: () => void;
        /** nobody has touched the frame for a while: the apparatus leaves */
        idle: boolean;
        /** rolling AND not held by the viewer: what the play button shows */
        live: boolean;
        /** sound on, and the fader up: the speaker glyph's three states */
        loud: 'high' | 'low' | 'off';
        menu: boolean;
        next: () => void;
        playbar: PlaybarSegment[];
        prev: () => void;
        restart: () => void;
        screen: () => void;
        /** the fraction the hand is holding while scrubbing, else null */
        scrubAt: null | number;
        scrubDown: (e: PointerEvent) => void;
        scrubLeave: () => void;
        scrubMove: (e: PointerEvent) => void;
        scrubUp: (e: PointerEvent) => void;
        /** keeps the bar's element, for the slider's live value */
        slider: ElementModifier;
        sound: boolean;
        subsOn: boolean;
        /** the bubble over the bar, while a pointer is on it */
        tip: null | ScrubTip;
        toc: () => void;
        toggle: () => void;
        /** measures the track, so the head can sit at the fill's end in pixels */
        trackWrap: ElementModifier;
        /** the master fader, 0..1 */
        vol: number;
        /** the fader's value as a custom property, for its own fill */
        volStyle: string;
    };
}
/**
 * THE PLAYER. The grammar every viewer knows from a decade of video on the
 * web: one full-width bar with the chapters as segments, a knob that sits
 * exactly where the fill ends, the transport on the left, the modes on
 * the right, the time beside the chapter's name, and the whole apparatus
 * fading off the picture when nobody is touching it. The bar listens: a
 * resting pointer gets the chapter and the time in a bubble and a ghost
 * fill to where it would cut, and every button names itself and its key.
 * The playhead is honest: a film cut on a chased lens cannot seek, so the
 * drag reads as time and the release RE-CUTS from the shot under the hand.
 */
export declare class Player extends Component<PlayerSignature> {
}
export interface BurstSignature {
    Args: {
        /** the animation ran out: take the glyph down */
        done: () => void;
        kind: 'pause' | 'play';
    };
}
/**
 * THE CONFIRMATION GLYPH: a play or a pause, once, in the middle of the
 * picture, gone in half a second — the way every player answers a tap
 * on the glass.
 */
export declare class Burst extends Component<BurstSignature> {
}
/** a chapter, as the menu lists it */
export interface MenuEntry {
    head: number;
    here: boolean;
    n: string;
    secs: number;
    shots: number;
    title: string;
}
export interface MenuSignature {
    Args: {
        contents: MenuEntry[];
        /** the key legend under the list */
        keys?: string;
        pick: (head: number) => void;
        sub: string;
        title: string;
    };
}
/**
 * THE DISC MENU. A film with chapters owes the viewer a way into them,
 * and the arrow keys alone are a secret. Picking one re-cuts the score
 * from that chapter's head — the same move the arrows make, because a
 * skip here is an edit and never a seek. The film keeps running behind
 * it, blurred: a menu that freezes the picture makes it feel like a file.
 */
export declare class Menu extends Component<MenuSignature> {
}
//# sourceMappingURL=player.d.ts.map