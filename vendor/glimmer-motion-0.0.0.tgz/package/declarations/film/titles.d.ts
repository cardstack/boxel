import Component from '@glimmer/component';
import type { FilmHandle } from './types.ts';
export interface GateSignature {
    Args: {
        film: FilmHandle;
    };
    Blocks: {
        default: [FilmHandle];
    };
}
/**
 * THE GATE — the front door. The film is narrated, so the door asks; and
 * the click that answers is the same gesture autoplay policy wants. The
 * scene stands behind it, already seated on the opening frame and
 * turning. What the door SAYS is the film's: the block is the front
 * matter, set in the title package (`cf-matter`, `cf-mg-*`), and the
 * shell here is the museum frame and the wash the type stands on.
 */
export declare class Gate extends Component<GateSignature> {
}
export interface EndCardSignature {
    Args: {
        film: FilmHandle;
    };
    Blocks: {
        default: [FilmHandle];
    };
}
/**
 * THE END CARD. It arrives a moment after the last line has settled, over
 * the held final frame — the film does not loop past its own ending;
 * watching again is the viewer's choice. Back matter is the same package
 * as the front, run in reverse order of importance.
 */
export declare class EndCard extends Component<EndCardSignature> {
}
//# sourceMappingURL=titles.d.ts.map