import Component from '@glimmer/component';
import type { Beat, ElementModifier } from './types.ts';
export interface InsertSignature {
    Args: {
        beat: Beat;
        /** the photograph failed to load: drop the plate */
        missing: () => void;
        src: string;
    };
}
/**
 * THE PHOTOGRAPH, cut in beside the model. The model is a model, and
 * there is a limit to what a film can claim with one; a real building at
 * the moment the commentary names it settles the claim. Wiped rather
 * than faded — a fade says "meanwhile", a wipe says "and here it is" —
 * and it carries its own credit.
 */
export declare class Insert extends Component<InsertSignature> {
}
export interface CaptionsSignature {
    Args: {
        /** the line being spoken */
        line?: string;
    };
}
/** CAPTIONS: the narration, printed — an accessibility track, and before
 *  any voice exists the only way to find out a line is too long */
export declare class Captions extends Component<CaptionsSignature> {
}
export interface TrackSignature {
    Args: {
        /** hands the film its leader, tether and ring */
        wire: ElementModifier<SVGSVGElement>;
    };
}
/**
 * THE GLASS keeps only what must connect DOM to world — the leader from a
 * caption, the mark's tether, the ring on a named point — projected
 * every frame by the film. The traces themselves live IN the scene.
 */
export declare class Track extends Component<TrackSignature> {
}
export interface StampSignature {
    Args: {
        /** a new element per step, so the strike replays from its own first frame */
        step: number;
        word: string;
    };
}
/** THE STAMP: a hanko, not a title — it lands hard, settles at once, and
 *  is simply replaced by the next; the lineup's roll call */
export declare class Stamp extends Component<StampSignature> {
}
//# sourceMappingURL=overlays.d.ts.map