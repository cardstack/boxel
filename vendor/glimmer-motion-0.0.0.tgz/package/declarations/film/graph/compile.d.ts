/**
 * THE GRAPH, COMPILED TO THE TABLE.
 *
 * A film written as a graph — a spine of chapters and shots, a join as a
 * sibling between two shots, everything else attached under the shot it
 * belongs to — compiles to the same `Beat[]` and `Chapter[]` the engine
 * has always run. That is the whole claim of Phase 2, and it is what
 * makes the migration measurable: the graph a film writes and the table
 * it used to write produce the same rows, to the key
 * (`tests/integration/film/graph-test.gts`), and therefore the same
 * schedule (`tests/fixtures/film/*.json`).
 *
 * Pure: a tree of plain nodes in, rows out. The components in
 * `nodes.gts` build the tree from the template; nothing here knows Ember.
 */
import type { ClipLook, ClipSpec } from '../clips.ts';
import type { PresentationComponent } from '../joins';
import type { Beat, Cam, Chapter, Join, JoinName, Over } from '../types.ts';
/** a patch on the row the shot compiles to: an attachment says what it adds */
export type Patch = Partial<Beat>;
export type GraphNode = AttachNode | EyeNode | GroupNode | JoinNode | LookNode | PatchNode | ShotNode | ToNode | VoiceNode;
/** a spine, a chapter or a sequence: a run of items with defaults for its shots */
export interface GroupNode {
    /** a chapter's row in the chapter table; only a `chapter` group has one */
    chapter?: Chapter;
    children: GraphNode[];
    /** shot facts every shot in the group inherits unless it says otherwise (`@cut`, `@hold`, `@bob`) */
    defaults: Patch;
    /** the seam every shot in the group is entered through unless a join sibling says otherwise */
    join?: Join;
    kind: 'group';
    name?: string;
    /** how deep those seams go, unless a join sibling says otherwise */
    over?: Over;
    /** attachments placed directly under the group: in force for every shot in it */
    patches: Patch[];
    role: 'chapter' | 'sequence' | 'spine';
}
/** a sibling between two shots: the seam INTO the next one */
/** a look a clip holds: collected by its clip, never by the beat */
export interface LookNode {
    kind: 'look';
    look: ClipLook;
}
export interface JoinNode {
    dipTo?: string;
    join: JoinName;
    kind: 'join';
    /** how deep this seam goes: over the picture alone, or over the furniture too */
    over?: Over;
    /** a presentation the score brought: named for the film, registered with it */
    presentation?: PresentationComponent;
    /** seconds the seam holds the picture; a brought presentation says */
    secs?: number;
}
export interface ShotNode {
    /** the head pose */
    cam: Cam;
    children: GraphNode[];
    /** the shot's own facts: cut, lead, lift, bob, hold, follow, to, dissolve, quality */
    facts: Patch;
    id: string;
    kind: 'shot';
    ticks: number;
}
/** the tail pose */
export interface ToNode {
    cam: Cam;
    kind: 'to';
}
/** an eye-level walk */
export interface EyeNode {
    eye: NonNullable<Beat['eye']>;
    kind: 'eye';
}
/** an attachment that says what it adds to the row: type, air, a stamp, a trace */
export interface PatchNode {
    kind: 'patch';
    patch: Patch;
}
/** the narration: the line, and the measured read the film cuts to */
export interface VoiceNode {
    gain?: number;
    hush?: boolean;
    kind: 'voice';
    line?: string;
    read?: number;
}
/** a window over a region the film does not own: a photograph, a freeze, a video */
export interface AttachNode {
    at?: number;
    end?: ClipSpec['end'];
    for?: number;
    kind: 'attach';
    media?: {
        caption: string;
        credit: string;
        kind: 'photo';
        src: string;
    } | {
        caption?: string;
        credit?: string;
        /** a pip's own fade, seconds */
        fade?: number;
        fit?: ClipSpec['fit'];
        in?: number;
        kind: 'freeze' | 'image' | 'video';
        look?: ClipLook;
        out?: number;
        /** a pip's corner radius, percent of its width */
        radius?: number;
        rate?: number;
        src?: string;
        volume?: number;
        /** a pip's width, percent of the frame */
        w?: number;
        /** a pip's left edge, percent of the frame */
        x?: number;
        /** a pip's top edge, percent of the frame */
        y?: number;
    };
}
export interface CompiledGraph {
    beats: Beat[];
    chapters: Chapter[];
    /** the spine's own seam: what a shot gets when nothing names one */
    defaultJoin?: Join;
    /** the spine's own depth: how deep a seam goes when nothing says */
    defaultOver?: Over;
    /** presentations the score brought, by the names its rows use */
    presentations: Record<string, {
        component?: PresentationComponent;
        over?: Over;
        secs: number;
    }>;
    voGain: Record<string, number>;
    voSecs: Record<string, number>;
}
export declare function compileGraph(root: GroupNode): CompiledGraph;
//# sourceMappingURL=compile.d.ts.map