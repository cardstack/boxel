/**
 * THE GRAPH'S HOST. Yields the vocabulary (`f.Spine`, `f.Shot`, …), walks
 * its markers after each render, compiles the tree to the table, and hands
 * the rows up. `<Film>` wraps its default block in one of these; a test can
 * render one bare and read what a template compiles to.
 *
 * Collection is scheduled, never done in the render pass: a marker's
 * modifier calls `invalidate()` during render, and a tracked write there
 * would be a backtracking re-render. One frame later the tree is walked
 * once, however many markers moved.
 */
import Component from '@glimmer/component';
import { CLIP_LOOK, IFRAME_PICTURE, SOUND } from './adjust';
import { type CompiledGraph } from './compile.ts';
import { Attach, Chapter, Eye, Freeze, type GraphHost, Insert, Inset, JoinInto, Lineup, Mark, Sequence, Shot, Sky, Spine, Stamp, To, Trace, Type, Video, Voice } from './nodes';
/** what `<Film as |f|>` and `<FilmGraph as |f|>` yield: the vocabulary */
export interface FilmVocabulary {
    Attach: typeof Attach;
    Chapter: typeof Chapter;
    Eye: typeof Eye;
    Freeze: typeof Freeze;
    Insert: typeof Insert;
    Inset: typeof Inset;
    Join: typeof JoinInto;
    Lineup: typeof Lineup;
    Mark: typeof Mark;
    Sequence: typeof Sequence;
    Shot: typeof Shot;
    Sky: typeof Sky;
    Spine: typeof Spine;
    Stamp: typeof Stamp;
    To: typeof To;
    Trace: typeof Trace;
    Type: typeof Type;
    Video: typeof Video;
    Voice: typeof Voice;
    /** the picture's adjustments, as the picture declares them */
    clip: typeof CLIP_LOOK;
    picture: typeof IFRAME_PICTURE;
    /** the sound actor's */
    sound: typeof SOUND;
}
export declare const VOCABULARY: FilmVocabulary;
export interface FilmGraphSignature {
    Args: {
        /** the compiled table, a frame after the markers settle; null when the block holds no spine */
        onCompile: (compiled: CompiledGraph | null) => void;
    };
    Blocks: {
        default: [FilmVocabulary];
    };
}
export declare class FilmGraph extends Component<FilmGraphSignature> implements GraphHost {
    private element?;
    private pending;
    invalidate(): void;
    /** the tree under the host, compiled; null without a spine */
    compile(): CompiledGraph | null;
    host: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: Element;
    }>;
}
//# sourceMappingURL=host.d.ts.map