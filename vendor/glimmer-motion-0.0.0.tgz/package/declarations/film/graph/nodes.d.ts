/**
 * THE GRAPH'S NODES, as components.
 *
 * Each renders a hidden marker and puts itself in a WeakMap the host walks
 * in document order — the same discovery `<Choreo>` uses for its steps —
 * so a shot's children are the markers inside its marker, a chapter's
 * shots are the markers inside its, and the template's nesting IS the
 * tree. `node()` is pure and cheap: it reads args and returns plain data;
 * the host compiles the tree to the table (`compile.ts`).
 *
 * The vocabulary is what the six sketches in docs/film-graph settled on:
 * `Spine` / `Chapter` / `Sequence` (groups, with defaults), `Shot` (the
 * head pose as its own args), `To`, `Eye`, `Join` (a sibling before the
 * shot it cuts into), `Type`, `Voice`, `Stamp`, `Sky`, `Mark`, `Trace`,
 * `Lineup`, and `Attach` around `Insert` / `Freeze` / `Video`. Adjustments
 * — the picture's own knobs — are in `adjust.gts`.
 */
import Component from '@glimmer/component';
import type { ClipLook, ClipSpec } from '../clips.ts';
import type { PresentationComponent } from '../joins';
import type { Beat, Join, JoinName, Over, PlateMode, Pt3 } from '../types.ts';
import type { AttachNode, EyeNode, GraphNode, GroupNode, JoinNode, LookNode, Patch, PatchNode, ShotNode, ToNode, VoiceNode } from './compile.ts';
export interface GraphProvider {
    node(): GraphNode;
}
/** the host a marker belongs to: the nearest `[data-film-graph]` ancestor */
export interface GraphHost {
    invalidate(): void;
}
export declare function setGraphHost(el: Element, host: GraphHost | undefined): void;
/** the nodes directly inside an element, in document order, nesting by markup */
export declare function collectGraph(el: Element): GraphNode[];
/**
 * A node component: a hidden marker in the tree, a provider in the map.
 * Groups and shots yield, so their children's markers nest under theirs.
 * The marker re-registers when its args change, and tells the host.
 */
export declare abstract class GraphNodeComponent<A extends object> extends Component<{
    Args: A;
    Blocks: {
        default: [];
    };
}> {
    abstract node(): GraphNode;
    protected mark: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: Element;
    }>;
}
interface GroupArgs {
    /** the same hand for every shot in the group, unless the shot says otherwise */
    bob?: number;
    cut?: boolean;
    hold?: boolean | 'top';
    /** the seam every shot in the group is entered through, unless a join sibling says otherwise */
    join?: Join;
    lead?: number;
    name?: string;
    /** how deep those seams go: over the picture alone, or over the type and the inserts too */
    over?: Over;
}
/** the film's spine: a sequence of chapters and shots; `@join` is what a shot gets when nothing names one */
export declare class Spine extends GraphNodeComponent<GroupArgs> {
    node(): GroupNode;
}
/** a chapter: a named sequence the menu and the rail read; its grade and stock are the chapter's, not its shots' */
export declare class Chapter extends GraphNodeComponent<GroupArgs & {
    grade?: string;
    lut?: string;
    n: string;
    tint?: string;
    tintD?: string;
    title: string;
}> {
    node(): GroupNode;
}
/** a group of shots inside a chapter: `c.Sequence` wearing the film's defaults */
export declare class Sequence extends GraphNodeComponent<GroupArgs> {
    node(): GroupNode;
}
/** the pose the film speaks in, as flat arguments */
interface PoseArgs {
    dolly: number;
    fx?: number;
    fz?: number;
    lookY: number;
    ox?: number;
    pitch: number;
    yaw: number;
}
/** one shot: its head pose as its own args, its facts, and everything attached under it */
export declare class Shot extends GraphNodeComponent<PoseArgs & {
    bob?: number;
    cut?: boolean;
    dissolve?: boolean;
    follow?: false | string;
    hold?: boolean | 'top';
    lead?: number;
    lift?: number;
    name: string;
    quality?: number;
    ticks: number;
    /** a point on the subject this shot is naming — the callout's leader and ring */
    to?: Pt3;
}> {
    node(): ShotNode;
}
/** the pose at the shot's tail; without one the shot holds */
export declare class To extends GraphNodeComponent<PoseArgs> {
    node(): ToNode;
}
/** a ground-level eye with a wide lens: standing at `@from`, walking to `@to` */
export declare class Eye extends GraphNodeComponent<{
    fov: number;
    from: Pt3;
    to?: Pt3;
}> {
    node(): EyeNode;
}
/**
 * The seam INTO the shot that follows it: one of the film's twelve by
 * name, or a presentation component the score brings — given the still,
 * told how long it has (`@secs`), and known to the film by nothing else.
 */
export declare class JoinInto extends GraphNodeComponent<{
    /** how deep this seam goes: over the picture alone, or over the furniture too */
    over?: Over;
    presentation: JoinName | PresentationComponent;
    /** seconds a brought presentation holds the picture */
    secs?: number;
    to?: string;
}> {
    node(): JoinNode;
}
/** a patch node: an attachment that says what it adds to the row */
export declare abstract class PatchComponent<A extends object> extends GraphNodeComponent<A> {
    abstract patch(): Patch;
    node(): PatchNode;
}
/** the type: the lower third, the title, the plate and the point */
export declare class Type extends PatchComponent<{
    bare?: boolean;
    gloss?: string;
    kicker?: string;
    mode?: PlateMode;
    reading?: string;
    says?: string[];
    word?: string;
}> {
    patch(): Patch;
}
/** the narration: the line, the measured read it was cut to, and the level it was mixed to */
export declare class Voice extends GraphNodeComponent<{
    gain?: number;
    hush?: boolean;
    line?: string;
    read?: number;
}> {
    node(): VoiceNode;
}
/** the year the voice says, written enormous in the scene */
export declare class Stamp extends PatchComponent<{
    at?: number;
    year: number;
}> {
    patch(): Patch;
}
/** type standing out in the world, behind the subject */
export declare class Sky extends PatchComponent<{
    az?: number;
    dist?: number;
    lines: string[];
    opacity?: number;
    size: number;
    track?: number;
    y: number;
}> {
    patch(): Patch;
}
/** a label that stands in the scene at the height it names */
export declare class Mark extends PatchComponent<{
    at?: number;
    bearing: number;
    hold?: number;
    lines: string[];
    r: number;
    size: number;
    to: number;
}> {
    patch(): Patch;
}
/** a line drawn ON the subject, in world coordinates; several add up */
export declare class Trace extends PatchComponent<{
    pts: Pt3[];
    wide?: boolean;
}> {
    patch(): Patch;
}
/** the lineup: cycle through subjects inside one held shot */
export declare class Lineup extends PatchComponent<{
    steps: NonNullable<Beat['cycle']>;
}> {
    patch(): Patch;
}
/** a window on the shot's clock over a photograph, a freeze or a video */
export declare class Attach extends GraphNodeComponent<{
    at?: number;
    end?: ClipSpec['end'];
    for?: number;
    lane?: number;
}> {
    node(): AttachNode;
}
/** a photograph cut in beside the model; `@src` resolves under the film's assets */
export declare class Insert extends GraphNodeComponent<{
    caption: string;
    credit: string;
    src: string;
}> {
    node(): AttachNode;
}
/** a freeze of the picture itself, read back and held */
export declare class Freeze extends GraphNodeComponent<{
    caption?: string;
    credit?: string;
    fit?: ClipSpec['fit'];
}> {
    node(): AttachNode;
}
/**
 * A LOOK HELD ON A CLIP — `f.clip.Look`. The clip actor's own adjustment,
 * declared by the film because the film draws the clip layer, in the same
 * shape as `f.picture.Look`: a value held on an actor for the window it
 * is attached to, applying to everything under it.
 *
 * ```hbs
 * <f.Inset @src="b-roll.mp4" @x={{62}} @y={{14}} @w={{30}}>
 *   <f.clip.Look @sat={{0.15}} @con={{1.2}} @blur={{1}} />
 * </f.Inset>
 * ```
 */
export declare class ClipLookNode extends GraphNodeComponent<ClipLook> {
    node(): LookNode;
}
/**
 * A PICTURE IN THE PICTURE: a video or a still placed as a LAYER, sized
 * and positioned in percent of the frame, with its own fade in and out.
 * Not the editorial photograph (`Insert`), which is a paper card in a
 * fixed corner — this one is a layer the score places.
 */
export declare class Inset extends GraphNodeComponent<{
    at?: number;
    end?: ClipSpec['end'];
    fade?: number;
    for?: number;
    in?: number;
    out?: number;
    radius?: number;
    rate?: number;
    src: string;
    still?: boolean;
    volume?: number;
    w?: number;
    x?: number;
    y?: number;
}> {
    node(): AttachNode;
}
/** a video or a still, over the frame for the window */
export declare class Video extends GraphNodeComponent<{
    caption?: string;
    credit?: string;
    fit?: ClipSpec['fit'];
    in?: number;
    out?: number;
    rate?: number;
    src: string;
    still?: boolean;
    volume?: number;
}> {
    node(): AttachNode;
}
export {};
//# sourceMappingURL=nodes.d.ts.map