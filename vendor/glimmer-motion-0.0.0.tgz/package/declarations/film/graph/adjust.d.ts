/**
 * ADJUSTMENTS — the picture's own knobs, held for a shot (or a chapter, or
 * a group), as typed components the actor declares and the film yields.
 *
 * An adjustment is a value held on an actor for a window, applying to
 * everything under it — After Effects' adjustment layer, FCPXML's
 * `adjust-*`, Unity's volume overrides. A FILTER is the kind of adjustment
 * that processes the frame — a grade, a stock, a look — Motion's word,
 * MLT's, CSS's. Photoshop draws the line: a filter is a pixel operation,
 * an adjustment is a parameter held above the stack.
 *
 * The package ships the two base classes and nothing named after weather.
 * The set below is what the IFRAME PICTURE — the WebGL page behind both
 * reference films, addressed through the `Picture` port — declares; a
 * third picture declares its own and never sees `haze`. Today they
 * compile to fields on the row the engine reads; when the picture becomes
 * an actor with ports, they write the ports.
 */
import type { Beat } from '../types.ts';
import type { Patch } from './compile.ts';
import { ClipLookNode, PatchComponent } from './nodes';
/** a value held on an actor for the window it is attached to */
export declare abstract class Adjustment<A extends object> extends PatchComponent<A> {
}
/** an adjustment whose target is the frame: applied before a seam's still is taken */
export declare abstract class Filter<A extends object> extends Adjustment<A> {
}
/** the mood, the named look, and the stock — a filter: it processes the frame */
export declare class Look extends Filter<{
    grade?: string;
    look?: string;
    lut?: null | string;
}> {
    patch(): Patch;
}
/** the hour, the weather, the air */
export declare class Weather extends Adjustment<{
    haze?: number;
    hours?: number[];
    lightning?: number;
    over?: number;
    rain?: number;
    theme?: number;
    wx?: number;
    wxCut?: boolean;
}> {
    patch(): Patch;
}
/** settled snow and a pinned blizzard; `@off` clears them */
export declare class Winter extends Adjustment<{
    gust?: number;
    off?: boolean;
    pack?: number;
}> {
    patch(): Patch;
}
/** where the sun is, degrees */
export declare class Sun extends Adjustment<{
    az: number;
    el: number;
}> {
    patch(): Patch;
}
/** a backlight, standing opposite the lens */
export declare class Light extends Adjustment<{
    rim?: number;
}> {
    patch(): Patch;
}
/** the surroundings: the city, the field */
export declare class Set extends Adjustment<{
    city?: Beat['city'];
    grass?: boolean;
}> {
    patch(): Patch;
}
/** the construction clock, how far through the shot it finishes, and which subject stands */
export declare class Build extends Adjustment<{
    by?: number;
    clock?: Beat['build'];
    settle?: number;
    subject?: number;
}> {
    patch(): Patch;
}
/** trims on the page's buses for the window */
export declare class Mix extends Adjustment<{
    music?: number;
    sfx?: number;
    voice?: number;
    wx?: number;
}> {
    patch(): Patch;
}
/** what the iframe picture yields as `f.picture` */
export declare const IFRAME_PICTURE: {
    Build: typeof Build;
    Light: typeof Light;
    Look: typeof Look;
    Set: typeof Set;
    Sun: typeof Sun;
    Weather: typeof Weather;
    Winter: typeof Winter;
};
/** what the sound actor yields as `f.sound` */
export declare const SOUND: {
    Mix: typeof Mix;
};
export declare const CLIP_LOOK: {
    readonly Look: typeof ClipLookNode;
};
//# sourceMappingURL=adjust.d.ts.map