import type Owner from '@ember/owner';
import Component from '@glimmer/component';
import { type BeaconRef } from './choreo/beacons.ts';
import Changeset from './choreo/changeset.ts';
import { type Pass } from './choreo/far.ts';
import { type GestureRef } from './choreo/gesture.ts';
import { type ChoreoHost, type ChoreoProvider } from './choreo/registry.ts';
import { type ChoreoRun } from './choreo/run.ts';
import { Aim, Attach, Camera, Camera3D, Crossing, Follow, Frame, Gate, Hold, Move, Pan, Parallel, Perform, Raise, Scroll, Sequence, SlowZoom, Spring, Tether, Tween, Wait } from './choreo/steps';
import type { Camera3DState, CameraState, ChoreoNode, PerformCommand, Query } from './choreo/types.ts';
/** `{{c.kept 'card'}}` narrows by role; bare `{{c.kept}}` is handed over uncalled, so the function is a Query too */
type Selector = ((role?: string) => Query) & Query;
/** what the region yields: the step components and the sprite queries */
export interface ChoreoContext {
    Aim: typeof Aim;
    Attach: typeof Attach;
    Camera: typeof Camera;
    Camera3D: typeof Camera3D;
    Crossing: typeof Crossing;
    Follow: typeof Follow;
    Frame: typeof Frame;
    Gate: typeof Gate;
    Hold: typeof Hold;
    Move: typeof Move;
    Pan: typeof Pan;
    Parallel: typeof Parallel;
    Perform: typeof Perform;
    Raise: typeof Raise;
    Scroll: typeof Scroll;
    Sequence: typeof Sequence;
    SlowZoom: typeof SlowZoom;
    Spring: typeof Spring;
    Tether: typeof Tether;
    Tween: typeof Tween;
    Wait: typeof Wait;
    /** open the gate the run is parked at; template-stable, because gates are wired in templates */
    advance: () => void;
    all: Selector;
    /** `{{c.beacon 'trash'}}` — a named box to borrow, for Move's @from / @to */
    beacon: (name: string) => BeaconRef;
    /**
     * Where the region's frame stands — tracked, updated when a camera step
     * lands or cancels, deliberately not per frame (§9): app logic may derive
     * from it (the zoom-threshold transmute) without a feedback loop.
     */
    readonly camera: CameraState;
    /** the removed half an arriving element claimed — orphaned, ready to cross-fade */
    counterpart: Selector;
    /** the live drag as geometry: its pose as a box, its velocity into springs */
    gesture: GestureRef;
    id: (id: string) => Query;
    inserted: Selector;
    kept: Selector;
    moved: Selector;
    /** narrow any query to sprites a viewport can actually see (§4.7) */
    onstage: (query: Query) => Query;
    /** kept only because it claimed a leaver's identity: the receiving half of a counterpart or far match */
    received: Selector;
    removed: Selector;
    role: (role: string) => Query;
    /** the current pass's run, as a value you can hold — null between passes (§4.6) */
    readonly run: ChoreoRun | null;
    still: Selector;
}
interface Signature {
    Args: {
        /**
         * WHERE THE SHOT STANDS BEFORE THE FIRST RUN. A `@through` spline
         * prepends the pose in force, and with no prior run that pose is the
         * default rig — dolly 1, yaw 0 — somewhere no film ever authored. A
         * host that hard-opens on a known pose (it seated its own scene there
         * before the score existed) declares it here, and the first segment
         * starts from the shot instead of travelling to it. Read once, before
         * the first run; after that the pose in force is the run's own.
         */
        camera3dFrom?: Camera3DState;
        /** outline the region and its participants; console.table each run */
        debug?: boolean;
        id?: string;
        /**
         * A `c.Camera3D` cue moved the shot. Called every frame it changes —
         * scrubs included, since the pose is sampled from the score — with a
         * pose the host applies to whatever it is drawing with.
         */
        onCamera3D?: (state: Camera3DState) => void;
        /**
         * The dispatcher for `<c.Perform>` commands (§C4). Called once per
         * command as the run's clock comes to include it — during forward
         * playback as the clock crosses it, after a seek that lands past it,
         * and again for the whole remaining prefix after a backward fold.
         * Dispatches are deferred past the render pass, so a command may
         * mutate tracked state freely.
         */
        onPerform?: (command: PerformCommand) => void;
        /**
         * The backward half of the fold: the clock moved to before a command
         * the host already holds. Reset every commanded state here; the run
         * re-dispatches the remaining prefix, in order, immediately after.
         */
        onPerformReset?: () => void;
        /**
         * Freeze the rest of the page for the span of each run (§4.7): when a
         * run starts, every animation in the document that is running AT THAT
         * MOMENT — and that the run itself does not own — is paused, and played
         * again when the run lands or is cancelled. The run's own animations
         * are exempt by construction: the sweep happens before they exist.
         * Pausing is not stopping — a loop resumes exactly where it was, which
         * is what makes this safe to do to work the region did not write.
         * Animations that START during the run are not caught; gating those is
         * the host's job (the crossing flag the gallery's entrances check).
         */
        quiet?: boolean;
        /**
         * Treat a subtree swap as one crossing pass (§4.7): scroll intent is
         * applied inside the pass — after the swap renders, before final bounds
         * are measured — and the tempo control's zero means no run at all. The
         * region stays router-agnostic (§9): any swap qualifies, however the
         * host caused it.
         */
        route?: boolean;
        /** where the arriving scene wants the window: the top, or wherever the thunk says */
        scroll?: 'top' | (() => number);
    };
    Blocks: {
        default: [ChoreoContext];
    };
    Element: HTMLDivElement;
}
export declare class Choreo extends Component<Signature> implements ChoreoHost {
    private element?;
    private orphanLayer?;
    private raisedLayer?;
    private tetherLayer?;
    /** tracked mirror of the frame's resting state — see ChoreoContext.camera */
    cameraState: CameraState;
    /**
     * The same state, untracked, for the pass pipeline itself. A pass runs
     * inside computations that must not CONSUME the tracked mirror — a pass
     * that read it would be invalidated by the very landing it causes, and
     * the region would render forever.
     */
    /** where a c.Camera3D left the shot, carried between runs — seeded by
     *  `@camera3dFrom` when the host knows its own opening pose */
    private resting3d;
    private restingCamera;
    private participants;
    /** registered since the last pass */
    private arrived;
    /** destroyed before the pass that removed them has been processed */
    private claimed;
    /** removed participants this region is keeping alive in its orphan layer */
    private orphans;
    /** participants whose Presence is letting them go: removed once, not on every pass while they leave */
    private leaving;
    private snapshots;
    private rootSnapshot?;
    private passPending;
    private rendered;
    run?: ChoreoRun;
    private context;
    /** the last changeset this region built — read it from a property function or a test */
    changeset?: Changeset;
    constructor(owner: Owner, args: Signature['Args']);
    /** SPIKE (Lane): providers from outside the markup, appended to every collected tree */
    private contributors;
    contribute(provider: ChoreoProvider): () => void;
    /** the run an attachment drives: the one playing or holding, none between runs */
    currentRun(): ChoreoRun | null;
    /** the region's own steps in document order, then whatever was contributed from outside */
    private collectTree;
    register(node: ChoreoNode): () => void;
    claim(node: ChoreoNode): boolean;
    get renderDetector(): undefined;
    private snapshot;
    /** phase 1: what changed this pass, measured — nothing is played yet */
    measurePass(): Pass | undefined;
    /** phase 3: identities are settled — compile this region's timeline and play it */
    finishPass(pass: Pass): void;
    private orphanBounds;
    /** the fingerprint of the tree the current run compiled from (see treePrint) */
    private scorePrint?;
    /** the layout every participant stood in when the run compiled (see layoutPrint) */
    private layoutPrint?;
    /**
     * Where the stylesheet puts each participant, as a string.
     *
     * `offsetLeft/Top/Width/Height` and NOT a bounding rect, because the
     * difference is the whole point: a rect includes the transform a flight
     * is writing, so a moving element reads as different on every frame,
     * while offsets are the box layout asked for — steady under a transform,
     * and different the moment something actually reflows. Integers, too,
     * which quietly forgives the sub-pixel noise a busy page generates.
     *
     * A Move that animates real width/height (`@size={{true}}`) does change
     * these, so such a run never takes the fast path. That is the honest
     * answer rather than a missed optimisation: a run writing layout cannot
     * be told apart from a page writing layout without measuring.
     *
     * Offsets are accumulated up the offset chain to the region, not read
     * at the participant alone, because what a render moves may be an
     * ANCESTOR that is no participant of anything — Escort's seat, one
     * positioned wrapper carrying three participants. Read flat, the
     * fingerprint was blind to exactly the reflow a retarget makes, the
     * pass was declined, and the old run played on against the moved
     * layout: card, badge and shadow teleported a whole bay, together. The
     * walk stops at the region's edge so the page above it stays out of the
     * print — a busy neighbour reflowing above the region must not cancel
     * its runs.
     */
    private layoutOf;
    /**
     * Can this pass be declined outright? Only while a run is in flight, and
     * only when nothing the pass could discover would change it: no arrivals,
     * no retentions pending, every participant either present or already a
     * known leaver, the collected timeline tree fingerprints identical to the
     * one the run compiled from (an EDIT always replays), and every
     * participant standing in the same layout box it compiled in (a REFLOW
     * always replays — it is what a Move is FOR). Anything else takes the
     * full pipeline.
     */
    private fastKeep;
    /** what quiet() paused, accumulated across replaced runs, resumed as one */
    private quieted;
    private quiet;
    private unquiet;
    private orphan;
    /** a removed sprite's row has ended */
    private finish;
    private drop;
    private log;
    host: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: HTMLDivElement;
    }>;
    layer: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: HTMLDivElement;
    }>;
    raised: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: HTMLDivElement;
    }>;
    tethers: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: SVGSVGElement;
    }>;
}
export default Choreo;
//# sourceMappingURL=choreo.d.ts.map