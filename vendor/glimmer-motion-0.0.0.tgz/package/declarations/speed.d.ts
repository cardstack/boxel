/**
 * Slow motion — a global divisor applied to every transition this binding
 * hands the engine.
 *
 * Not a Motion feature: Motion has no global time scale. Setting `speed` on a
 * running animation is not it either — an animation recomputes its own time
 * when its speed changes, so a spring mid-flight jumps rather than slows. What
 * works is scaling the *transition* before the engine ever sees it, so the
 * animation is simply born slower.
 *
 *   setMotionSpeed(5)   // transitions started from now on take five times as long
 *   setMotionSpeed(1)   // back to normal
 *
 * Applies to whatever starts after the change, not to what is already running.
 * Meant for looking at a transition closely.
 */
import type { Transition } from 'motion-dom';
export declare function motionSpeed(): number;
export declare function setMotionSpeed(next: number): void;
export declare function onMotionSpeed(fn: (divisor: number) => void): () => void;
/** the same transition, taking `k` times as long — per-value overrides included */
export declare function scaleTransition(transition: Transition | undefined, k: number): Transition | undefined;
/** scale a transition by the divisor in force right now */
export declare const slowed: (transition: Transition | undefined) => Transition | undefined;
//# sourceMappingURL=speed.d.ts.map