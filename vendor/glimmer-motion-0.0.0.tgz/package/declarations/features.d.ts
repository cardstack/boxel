export declare function initFeatures(): void;
//# sourceMappingURL=features.d.ts.map