import type Owner from '@ember/owner';
import Component from '@glimmer/component';
import { type NodeGroup } from 'motion-dom';
/**
 * LayoutGroup for Glimmer — Motion's components/LayoutGroup:
 *   - `@id`: namespaces every `layoutId` beneath it (nested groups append: "a-b")
 *   - `@inherit`: true (default) shares the parent's projection group and id, "id" shares only the id,
 *     false starts a fresh group
 *   - yields the context { id, group, forceRender }, which is what React's LayoutGroupContext holds
 *
 * It also hosts boxel-motion's render detector: a getter that consumes the volatile tag is re-evaluated
 * on every render pass — BEFORE the DOM is patched. That is where React calls getSnapshotBeforeUpdate,
 * so projection nodes snapshot there and measure again once the render has landed.
 *
 * React's LayoutGroup renders no DOM; here a `display: contents` wrapper makes the group discoverable
 * from any motion element below it without threading arguments through the tree.
 */
type Inherit = boolean | 'id';
export interface LayoutGroupContext {
    readonly forceRender: () => void;
    readonly group?: NodeGroup;
    readonly id?: string;
}
/** the nearest group context above an element, if any */
export declare function closestLayoutGroup(el: Element): LayoutGroupContext | undefined;
interface Signature {
    Args: {
        id?: string;
        inherit?: Inherit;
    };
    Blocks: {
        default: [LayoutGroupContext];
    };
}
/** React: a motion element snapshots its layout (getSnapshotBeforeUpdate) whenever it re-renders; here
 *  a render pass snapshots every projection node, once, and settles after the pass (boxel-motion's trick) */
export declare function snapshotOnRender(): void;
export declare class LayoutGroup extends Component<Signature> {
    element?: HTMLElement;
    private version;
    private ownGroup;
    readonly context: LayoutGroupContext;
    constructor(owner: Owner, args: Signature['Args']);
    get inherit(): Inherit;
    get parent(): LayoutGroupContext | undefined;
    /** id composition: upstream-id + "-" + own id, or the upstream id when we have none (only when inheriting) */
    get effectiveId(): string | undefined;
    get effectiveGroup(): NodeGroup;
    register: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: HTMLElement;
    }>;
    get renderDetector(): undefined;
}
export default LayoutGroup;
//# sourceMappingURL=layout-group.d.ts.map