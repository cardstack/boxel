/**
 * MotionConfig for Glimmer — Motion's components/MotionConfig: defaults for every motion element below it.
 * React merges the context into each element's props (`{ ...config, ...props }`); here the element looks
 * up its closest <MotionConfig> ancestor in the DOM and merges the same way on every update pass.
 *
 *   <MotionConfig @transition={{hash type="spring"}} @reducedMotion="user">…</MotionConfig>
 */
import Component from '@glimmer/component';
import { type ReducedMotionConfig, type Transition } from 'motion-dom';
import type { TransformPoint } from 'motion-utils';
export interface MotionConfigContext {
    /** CSP nonce for the <style> elements the binding injects (popLayout) */
    nonce?: string;
    /** "user" (the default here) respects prefers-reduced-motion, "always" forces it, "never" ignores it — React's default */
    reducedMotion?: ReducedMotionConfig;
    /** complete every animation instantly (E2E / visual regression runs) */
    skipAnimations?: boolean;
    /** corrects pointer coordinates for drag — see correctParentTransform / transformViewBoxPoint */
    transformPagePoint?: TransformPoint;
    /** default transition for the tree; `inherit: true` shallow-merges with the parent config's */
    transition?: Transition;
}
interface Signature {
    Args: MotionConfigContext;
    Blocks: {
        default: [];
    };
    Element: HTMLElement;
}
/** the merged config in effect for an element — React's useContext(MotionConfigContext) */
export declare function closestMotionConfig(el: Element): MotionConfigContext;
export declare class MotionConfig extends Component<Signature> {
    private host?;
    register: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: HTMLElement;
    }>;
    /** inherits from the closest parent MotionConfig, then applies its own args (transition via resolveTransition) */
    get config(): MotionConfigContext;
}
export default MotionConfig;
//# sourceMappingURL=motion-config.d.ts.map