import { type ViewTransitionBuilder, type ViewTransitionOptions } from 'motion-dom';
export type ViewTransitionUpdate = () => void | Promise<void>;
export type { ViewTransitionBuilder, ViewTransitionOptions, ViewTransitionTargetDefinition, } from 'motion-dom';
export declare function animateView(update: ViewTransitionUpdate, options?: ViewTransitionOptions): ViewTransitionBuilder;
export declare function viewTransition(update: ViewTransitionUpdate, root?: Element | null): Promise<void>;
//# sourceMappingURL=view-transition.d.ts.map