/**
 * THE CAMERA'S PATH — the arithmetic behind `c.Camera3D @through`, and
 * the only place in Choreo that owns a curve rather than a tween.
 *
 * Everything here is a pure function of PROGRESS. That is the whole
 * point: a seek must land the shot exactly where playing there would, so
 * nothing in this file may remember a previous frame. A spline that is
 * sampled rather than integrated can be scrubbed, rendered a frame at a
 * time, and played, and all three agree by construction.
 */
import type { Camera3DState, Camera3DWaypoint } from './types.ts';
/**
 * Sample the spline at overall progress p ∈ [0, 1] (uniform segments).
 *
 * SPLICES (docs/choreo-splices.md): a waypoint marked `cut` starts a new
 * SHOT. Each shot is a clamped spline of its own points — endpoint
 * tangents one-sided, so no shot's velocity crosses a seam — and each
 * shot's window runs from its first slot to the next seam, its points
 * spread uniformly across it. The outgoing shot therefore plays through
 * the seam instant (its motion stretches by one slot rather than
 * parking), the incoming one begins exactly on it, and the sampled pose
 * is a step function at the seam. Waypoints keep their uniform slots, so
 * cues anchored to waypoint moments keep their clock. A cut on the first
 * waypoint drops the pose-in-force seed: the score opens inside its
 * first shot.
 */
export declare function sampleThrough(from: Camera3DState, through: Camera3DWaypoint[], progress: number, tension?: number): Camera3DState;
/**
 * A SETTLE — the operator's second hand, written as a function of time.
 *
 * A cardinal spline crosses its waypoints with continuous velocity but
 * not continuous acceleration: at every control point the curvature
 * steps, and the eye reads that step as a tick. The usual cure is a
 * spring chasing the pose, which works and costs the two things a
 * seekable engine cannot pay — it remembers the last frame, so a scrub
 * lands somewhere a play would not, and it lags, so the camera is always
 * behind the score by however much smoothing it was given.
 *
 * This is the same cure without either cost: the reported pose is a
 * Hann-weighted average of the SAME spline sampled around the current
 * progress. Averaging a curve is a low-pass filter, and a Hann window
 * kills the acceleration steps outright, so the result is a hand rather
 * than a mechanism. Being centred, it has no lag — it reads slightly
 * ahead of the score exactly as much as it reads behind. Being an
 * average of one pure function, it is still a pure function: play,
 * scrub and frame-by-frame render all report the same pose.
 *
 * TWO EDGES IT MUST NOT CROSS. A cut is a step in the pose on purpose,
 * and an average that straddled it would smear the cut into a very fast
 * pan. The window is therefore TAPERED to the shot the progress is in:
 * near either edge the kernel shrinks to the room it has, reaching zero
 * at the edge itself. So a cut stays a cut, a path still lands exactly
 * on its last waypoint, and the pose handed forward to the next cue is
 * the waypoint rather than an average of one — the filter is an identity
 * at every boundary and a smoother everywhere else.
 *
 * The taper is `tanh`, not a `min`, and the difference is the whole
 * reason it works. A hard `min(width, 2 × room)` has a corner in it
 * where the two branches meet, and a filter whose width has a corner
 * puts one back into what it filters: measured against a path with two
 * right-angle corners in it, the hard taper LOST ground as the window
 * widened (worst jerk 8.7e-4 at a window of 0.175, 2.5e-3 at 0.3) while
 * the smooth one held 8.0e-4 at every width against 4.2e-3 unfiltered.
 * `tanh(x) ≤ x` everywhere, which is what keeps the taps inside the
 * shot; it is smooth, which is what keeps the tick out.
 *
 * `width` is in progress, not seconds: the kinks being filtered are at
 * the waypoints, which are spread uniformly across the clock, so a
 * window measured against the clock is a window measured against the
 * spacing of the things it exists to smooth. The caller converts.
 */
export declare function settleThrough(from: Camera3DState, through: Camera3DWaypoint[], progress: number, tension: number | undefined, width: number, taps?: number): Camera3DState;
//# sourceMappingURL=path.d.ts.map