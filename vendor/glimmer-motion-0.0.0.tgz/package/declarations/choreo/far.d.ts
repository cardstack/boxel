import type { ChoreoNode, Sprite } from './types.ts';
/** one region's measured pass, waiting for the others before it runs */
export interface Pass {
    claimed: ChoreoNode[];
    host: PassHost;
    inserted: Sprite[];
    kept: Sprite[];
    removed: Sprite[];
    root: HTMLElement;
}
export interface PassHost {
    /** phase 3: compile and play, now that identities have been reconciled */
    finishPass(pass: Pass): void;
    /** phase 1: snapshot vs. now, into a changeset — no animation started yet */
    measurePass(): Pass | undefined;
}
export declare function setPassScheduler(fn: (run: () => void) => void): void;
/**
 * Announce that this region has a pass coming. Called while Glimmer is still
 * rendering, so by the time the barrier runs, every region taking part in this
 * pass is known — which is what lets the match be synchronous.
 */
export declare function join(host: PassHost): void;
export declare function leave(host: PassHost): void;
/**
 * Drop a barrier that will never run. A test torn down between `join` and the
 * post-render callback leaves a destroyed region parked in `intents`, and the
 * next test's first pass would try to measure it. `setupMotion(hooks)` calls
 * this.
 */
export declare function resetBarrier(): void;
export declare function setBeforeMeasure(fn: () => void): void;
//# sourceMappingURL=far.d.ts.map