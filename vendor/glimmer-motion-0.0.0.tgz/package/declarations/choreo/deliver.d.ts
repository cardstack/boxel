import type { Cue, DeliveryBy, Easing, SpringSpec } from './types.ts';
interface Slot {
    el: HTMLElement;
}
interface Split {
    /** put the original nodes back; safe to call twice */
    restore(): void;
    slots: Slot[];
}
export declare function split(el: HTMLElement, by: Exclude<DeliveryBy, 'item'>): Split;
export interface Window {
    at: number;
    ms: number;
}
/**
 * `@stagger` seconds between starts, window = what remains of the span; with
 * no stagger, the Build Order demo's policy: a 0.55-of-span window with the
 * starts distributed across the remainder.
 */
export declare function windows(n: number, span: number, stagger: number): Window[];
/** cue.target, as WAAPI property-indexed keyframes */
export declare function keyframesOf(target: Record<string, unknown>, times?: number[], ease?: string): PropertyIndexedKeyframes;
export declare function cssEasing(ease: Easing | undefined, ms: number): string;
/** a spring's clock, pre-sampled: its real duration and a linear() easing */
export declare function springEasing(spec: SpringSpec | undefined): {
    easing: string;
    ms: number;
};
export interface Delivery {
    cancel(): void;
    /** finish NOW: land the end values and give the text back — a scrub past
     *  the cue's end must not leave paused spans standing in for the sprite */
    complete(): void;
    finished: Promise<void>;
    pause(): void;
    play(): void;
    /** place the whole delivery at `ms` past its cue start (unscaled) */
    seek(ms: number): void;
    speed(rate: number): void;
}
/** play one delivery cue: split, animate the slots, restore, land the end values */
export declare function deliver(cue: Cue, speed: number): Delivery;
export {};
//# sourceMappingURL=deliver.d.ts.map