/**
 * `c.gesture` — the live drag as a first-class geometry source (§6.1, §6.4).
 *
 * A document-level pointer tracker (listeners, not timers) keeps the last
 * pointer position and a short velocity window. A Move that borrows
 * `{{c.gesture}}` as its `@from` starts from wherever the finger let go —
 * sized as the sprite, centred on the pointer — and any spring that flies
 * it inherits the pointer's velocity, so a toss leaves at the speed it was
 * thrown.
 */
import type { Bounds, Rect } from './types.ts';
export interface GestureRef {
    gesture: true;
}
export declare const GESTURE: GestureRef;
export declare function isGestureRef(v: unknown): v is GestureRef;
/** idempotent; the first <Choreo> turns it on */
export declare function trackGestures(): void;
/** the pointer's page position now, or null before any pointer event */
export declare function gesturePoint(): {
    x: number;
    y: number;
} | null;
/** units per second over the recent window — what a spring inherits */
export declare function gestureVelocity(): {
    x: number;
    y: number;
};
/** the gesture as a box: the sprite\'s own size, centred on the pointer */
export declare function gestureBounds(size: Rect): Bounds | null;
/** test-support: forget everything between tests */
export declare function resetGestures(): void;
//# sourceMappingURL=gesture.d.ts.map