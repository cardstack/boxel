import type { Camera3DState, CameraState, ChoreoNode, Compiled, Cue, PerformCommand, Sprite } from './types.ts';
/** how fast each value was moving, in units per second, keyed by element then property */
export type Velocities = Map<HTMLElement, Map<string, number>>;
export interface Run {
    /** open the gate the run is parked at; mid-segment, complete the segment and park (§4.1) */
    advance(): void;
    /** stop everything; removed sprites are released unless a next run is keeping them (`keep`) */
    cancel(keep?: Set<ChoreoNode>): void;
    cues: Cue[];
    /** the run's full length in seconds at 1×, gates included */
    readonly duration: number;
    finished: Promise<void>;
    /** nothing left to play: the run completed or was cancelled */
    isDone(): boolean;
    /**
     * The sprites this run is DRIVING through space right now — an
     * unfinished move/spring/tween writing geometry — with each cue's
     * transition. A replacement pass reads this to complete its score: a
     * flying sprite the new score does not name gets a continuation move
     * instead of a one-frame release to rest (§3.1).
     */
    midflight(): Map<ChoreoNode, Record<string, unknown> | undefined>;
    /** standing at a gate, waiting for advance() — a still, and settled */
    readonly parked: boolean;
    pause(): void;
    /**
     * The run is not advancing itself: paused, parked at a gate, or otherwise
     * held. Its clock belongs to whoever stopped it.
     *
     * A held run keeps writing: inline width, height and transform stay on
     * every sprite it owns, so the geometry the page reports is the run's
     * rather than the stylesheet's. Anything deciding whether the world has
     * changed by measuring it has to know not to trust what it sees.
     */
    readonly paused: boolean;
    play(): void;
    /** a pass measured and decided to keep this run: put the picture back */
    reassert(): void;
    /** put every element this run has touched back to its resting layout NOW */
    releaseForMeasure(): void;
    /**
     * One build backwards — Keynote's rule. Land PARKED at the previous
     * gate with everything ahead re-closed, and HOLD: a retreat never
     * plays, never self-opens a @delay gate, and the next advance() replays
     * the un-built segment forward. False when nothing stands behind the
     * clock (the caller falls through to whatever "back" means one level
     * out — an outer run, the previous slide).
     */
    retreat(): boolean;
    /** which gate-bounded segment the clock is in */
    readonly segment: number;
    /** playback rate: 1 is normal, 0.5 half, as Motion's controls */
    speed: number;
    /**
     * This run has no end of its own: its score is nothing but OPEN steps, so
     * it holds them — drawing its wires, keeping its holds — until it is
     * cancelled or replaced. A standing run is SETTLED, not in flight: there
     * is nothing to wait for, and `finished` will not resolve until a cancel.
     */
    readonly standing: boolean;
    /** the clock, in seconds at 1× — settable; setting it across a gate parks there */
    time: number;
    /** what every driven value was doing at the moment of interruption */
    velocities: Velocities;
}
interface RunOptions {
    /** where the region's frame stands as this run begins */
    camera?: CameraState;
    /** where the SHOT stands as this run begins — a 3D host's own pose */
    camera3d?: Camera3DState;
    /** the aim point the prior run left applied — see ChoreoRun.cameraAim */
    cameraAim?: {
        x: number;
        y: number;
    } | null;
    /** the element the camera transform drives (the region's scene wrapper) */
    cameraFrame?: HTMLElement;
    /**
     * Nothing in this region is staying — every participant it can see is a
     * leaver. See the note in `park`: it decides whether a gate this run stops
     * at is a gate anybody could still open.
     */
    doomed?: boolean;
    inherit?: Velocities;
    /** a camera step landed or the run ended: the frame's new resting state */
    onCamera?(state: CameraState): void;
    /**
     * The 3D shot moved. Called every frame a `c.Camera3D` cue changes the
     * pose — including on a scrub, because the pose is sampled from the
     * score rather than remembered from playback. Choreo has no renderer of
     * its own; this is where the host's does the drawing.
     */
    onCamera3D?(state: Camera3DState): void;
    /**
     * A `c.Perform` command entered the folded set: dispatch it (§C4).
     * Deferred past the render pass, in time order, once per fold entry.
     */
    onPerform?(command: PerformCommand): void;
    /**
     * The folded set shrank — the clock moved to before a command the host
     * already holds. Reset commanded state; the remaining prefix is
     * re-dispatched, in order, immediately after.
     */
    onPerformReset?(): void;
    onSpriteDone(sprite: Sprite): void;
    /** the region's elevated layer, where c.Raise promotes the living */
    raisedLayer?: HTMLElement;
    removed: Sprite[];
    /** the svg the tethers draw into */
    tetherLayer?: SVGSVGElement;
}
export declare class ChoreoRun implements Run {
    cues: Cue[];
    velocities: Velocities;
    finished: Promise<void>;
    private master;
    private playing;
    private parkedAt;
    private rate;
    private readonly scale;
    readonly standing: boolean;
    private readonly total;
    private readonly gates;
    private tracks;
    private readonly rowEnd;
    private released;
    private pending;
    private readonly options;
    private borrowedValues;
    /** rest is what releaseForMeasure jumps to: 0 for translates, 1 for scales, 'none' for clips */
    private movedValues;
    /** what the last releaseForMeasure retired, so a kept pass can put it back */
    private retired;
    private owned;
    private cancelled;
    private ended;
    private resolveFinished;
    private ticking;
    private autoTimer;
    constructor(compiled: Compiled, options: RunOptions);
    get duration(): number;
    get paused(): boolean;
    get time(): number;
    set time(seconds: number);
    get speed(): number;
    set speed(rate: number);
    get segment(): number;
    get parked(): boolean;
    /**
     * ATTACH: write each attached region's clock from this one's.
     *
     * Several windows may name one region — a film's every beat has a plate
     * window, and the plate is one region re-keyed per beat — so the run
     * resolves ONE governing window per region on every evaluate: the window
     * that holds `now`; else the latest past one, if it holds; else the
     * earliest future one, which stands the child at its head (Remotion's
     * premount: mounted early, clock frozen at `in`). The child's run is
     * paused and told `in + (now − start) × rate`. No history is kept on
     * either side, which is what makes a seek into a window land where
     * playing there would.
     */
    private driveAttachments;
    /** does this run's score integrate — a spring, a follow — so that its state is its history? */
    hasIntegrator(): boolean;
    isDone(): boolean;
    midflight(): Map<ChoreoNode, Record<string, unknown> | undefined>;
    pause(): void;
    play(): void;
    advance(): void;
    retreat(): boolean;
    private startTicking;
    private stopTicking;
    private tick;
    private park;
    private finish;
    private setPaused;
    private seekTo;
    /**
     * The one cost WAAPI acceleration charges a scrubbable run: a finished
     * accelerated animation commits its finals asynchronously, and that
     * commit can land AFTER a still's jump and overwrite it. So a still is
     * re-asserted on the two frames after it is entered — by then any
     * pending commit has landed, and the computed frame wins again.
     */
    private restillPending;
    private scheduleRestill;
    private restill;
    private evaluate;
    /** perform tracks whose commands the host currently holds (see foldPerforms) */
    private performed;
    /** dispatches queued for after the render pass, in fold order */
    private pendingPerforms;
    private performFlushBooked;
    /**
     * The command fold (§C4): the set of Perform cues at or before the
     * clock IS the commanded state. Every evaluate — a play tick and a seek
     * alike — re-derives the eligible set; growth dispatches the new
     * commands in time order, and any shrink (a backward seek) resets the
     * host first and replays the whole remaining prefix. Commands are
     * idempotent statements of state by contract (`lamp.on`, never a
     * toggle), which is exactly what makes the replay a re-derivation.
     *
     * Dispatches are DEFERRED past the render pass: the constructor's first
     * evaluate runs while Glimmer may still be rendering, and a command
     * exists to mutate application state. A reset collapses the queue — the
     * dropped dispatches were never seen, and the replay that follows
     * restates everything still standing.
     */
    private foldPerforms;
    /**
     * Stand rewound tracks back on their origins — the part of a backward
     * seek that must be ORDERED. A sprite with sequential cues has one
     * origin per cue, each equal to the previous cue's landing; restored
     * in track order they clobber forward and the sprite ends up standing
     * on its LAST future cue's origin (the Playhead demo's hand parked on
     * 'place' after a scrub to zero; its receipt refusing to dismiss). So:
     * latest-first, which leaves the EARLIEST future cue's origin — the
     * value the timeline actually holds at `now` — standing; and a key
     * that any track AT or BEFORE `now` writes is not touched at all,
     * because that track's own sample or landing is the answer.
     */
    private rewind;
    /** the eased progress of a plain clock-driven track */
    private flightlessProgress;
    /**
     * The orbit pose in force. Public for the same reason `camera` is: it is
     * hand-off state, and a replacement run must continue from where this
     * one left the shot rather than snapping back to the framing.
     */
    camera3d: Camera3DState;
    private readonly initial3d;
    camera: CameraState;
    /**
     * The aim point P in force, local px. With transform-origin pinned at
     * 0 0, the applied transform is translate(x + (1−z)·P) scale(z) — the
     * frame's centre cancels out of the algebra entirely, so neither a
     * board that reflows mid-cue nor a stage that changes height between
     * cues can move the picture: the formula reads no live DOM at all.
     * z = 1 is the identity for any P. Public because it is hand-off state:
     * the next run lerps from the point THIS run left aimed, exactly as it
     * inherits the camera.
     */
    cameraAim: {
        x: number;
        y: number;
    } | null;
    /**
     * The absolute pose a camera cue lands on, resolved against the pose it
     * starts from. Absolute fields pass through; missing fields hold; a
     * relative cue (Pan / SlowZoom) offsets and multiplies the pose in
     * force — which is why resolution happens AT START (live) or during the
     * prefix fold (reconstruction), never at compile.
     */
    private static resolveCameraTo;
    private cameraProgress;
    /**
     * The camera and aim this run inherited, frozen at construction — the
     * fold origin every reconstruction starts from. Public because a
     * replacement run that re-executes the SAME score must inherit this
     * origin, not the pose in force: the pose in force is what the score's
     * prefix already produced, and folding the prefix from it applies every
     * relative cue twice (the world-dock law).
     */
    readonly initialCamera: CameraState;
    readonly initialAim: {
        x: number;
        y: number;
    } | null;
    /**
     * Rebuild the camera fold from the score prefix before a seek's still
     * (notes/external-clock-camera-seek-handoff.md). Forward playback folds
     * each camera cue's landing into the run's cumulative camera as the
     * clock crosses it — but a random-access seek can jump clean over a
     * window, and a cue that never starts never folds: the clock reads `t`
     * while the picture holds an earlier shot. So every camera track's
     * bookkeeping (started, cameraFrom, aimFrom/aimTo, cameraP) is
     * re-derived here in timeline order from the run's initial camera;
     * evaluate() then recomputes exactly the numbers forward playback would
     * have produced, and play-after-scrub resumes from them. Pure
     * arithmetic over frozen numbers, like the rest of the camera: no DOM
     * is read, so backward and repeated seeks agree to the pixel.
     */
    private reconstructCameraAt;
    /**
     * The damped counter-scale (§6.4): steady sprites scale with the host but
     * not 1:1 — pow(z, .30) zoomed out so they stay readable, pow(z, .70)
     * zoomed in so they don't feel stuck, clamped to what the eye tolerates.
     */
    private static damped;
    /**
     * The frame's APPLIED transform for a camera state at aim progress `p`.
     *
     * Transform-origin is pinned at 0 0, so the applied transform is
     * translate(x + (1−z)·P) scale(z) with P the lerped aim point — pure
     * arithmetic over frozen numbers. Nothing here reads the DOM, so a board
     * that reflows mid-cue cannot move the camera, and every boundary
     * (landing, re-aim, next run) agrees to the pixel. At z = 1 the aim term
     * vanishes: an unpanned camera is EXACTLY the identity.
     */
    private appliedCamera;
    private static cameraCss;
    /**
     * Fly the region's frame on the platform: two transform keyframes and the
     * eased clock pre-sampled into a linear() easing. The biggest layer in the
     * region composites off the main thread for the whole move.
     */
    private startCameraAnimation;
    /**
     * Retire the frame's platform animation and hand the picture back to
     * inline style, written from the shadow state — so a cancel mid-zoom
     * freezes exactly where the eye was, and a landing holds its final.
     */
    private dropCameraAnimation;
    private applyCamera;
    private tetherDrawScheduled;
    private scheduleTetherDraw;
    /**
     * One frame of a derived value (§4.10): compose the context from the
     * pass's measurements, hand it to the author's function, write what
     * comes back.
     *
     * Nothing here touches the DOM — that is the design, not an
     * optimisation (docs/postmortem-follow.md). The resting boxes were
     * measured by the pass with every moved value released, and a source's
     * `now` is its resting box composed with the motion values driving it
     * this frame: JS-side numbers, not a measurement. So a follower is pure
     * BY CONSTRUCTION — there is no live box in reach, it cannot read back
     * its own output, and it cannot force a style recalculation in the
     * middle of a move. It is also correct under INTERRUPTION for free: a
     * replacement run's pass re-measures, so a run born mid-flight computes
     * from rests that are right immediately, with no "last frame" to
     * disagree with.
     *
     * `set`, not an animation: a derived value IS the frame, so there is
     * nothing to interpolate toward and nothing the compositor could be
     * given — this is the main-thread cost the step charges, and the reason
     * it is the same cost `c.Tether` already pays.
     */
    private drive;
    /** the window closed (or was scrubbed out of): put the declared rest back */
    private restDerived;
    private drawTether;
    /**
     * The scale between the layer's own pixels and the screen's, per axis.
     *
     * A promotion reads client rects and writes LOCAL pixels, and every
     * transform above the region — a camera zoom, a page crossing carrying the
     * whole scene, any ancestor with a scale on it — sits between the two. Read
     * off the layer itself: its rect is what the screen shows, its offset size
     * is what its own coordinate system calls that. Dividing by the camera zoom
     * alone would catch the region's own transform and miss everything outside
     * it, which is the double-scale the tether draw already dodges by mapping
     * through the screen CTM.
     */
    private static layerScale;
    private promote;
    private restore;
    private startScroll;
    private stopScroll;
    /** stop a track's animations at the value level — an async animation
     *  cancelled before it resolves stays 'idle' forever if only the controls
     *  are stopped, and its value then reads as animating for good */
    private stopTrack;
    /** land a cue's end values without ever having played it */
    private jumpFinals;
    private startTrack;
    /** put the sprite at progress `p` of its sampled flight path (§4.4) */
    private applyFlight;
    /** the eased progress a flight sits at, `ms` into its window */
    private flightProgress;
    /**
     * The sampled path as platform keyframes: each point becomes a transform,
     * uniformly spaced (the points were sampled uniformly in progress), and
     * the eased clock rides the animation's easing instead of per-frame JS.
     */
    private flightKeyframes;
    private startFlight;
    /** compute one still frame of a cue and jump the values onto the element */
    private sampleStill;
    private completeTrack;
    private pinStarts;
    private sampleVelocities;
    releaseForMeasure(): void;
    /**
     * A pass measured this run's world at rest and then decided to KEEP the
     * run — but the measurement itself was destructive: releaseForMeasure
     * cancels platform animations, returns borrowed values, and jumps every
     * moved value to rest, and a MotionValue.jump() STOPS the animation
     * driving it. Left like that, a kept run keeps its clock and its landing
     * but loses its picture: the flight freezes at rest until the finals
     * land — which on a busy page (the gallery: neighbours re-pass the
     * region every render) is every crossing, every time. So the keep path
     * calls this: moved and borrowed values are stood back where they were,
     * their bookkeeping is re-registered, every in-flight track's animation
     * is retired so evaluate re-enters it — the machinery a scrub-then-play
     * already uses — and the re-entered animations are seeked back onto the
     * run's own clock, so a keep is invisible rather than a restart.
     */
    reassert(): void;
    cancel(keep?: Set<ChoreoNode>): void;
}
/** every live run, for the test helpers that drive gates and clocks */
export declare const activeRuns: Set<ChoreoRun>;
export declare function execute(compiled: Compiled, options: RunOptions): ChoreoRun;
export {};
//# sourceMappingURL=run.d.ts.map