import type { Run } from './run.ts';
/** the sliver of a region a watch needs: the run it is playing right now */
export interface ArmingRegion {
    readonly run: Run | null | undefined;
}
export interface Arming {
    /** tracked: a crossing this arming is watching is under way */
    active(): boolean;
    /**
     * Arm now, and watch `region` until the run that survives has settled (or
     * the deadline passes). Called again while armed, it re-arms: the earlier
     * watch is abandoned rather than allowed to stand the new one down.
     */
    begin(region: ArmingRegion): void;
    /** stand down by hand — a test reset, or a host that knows the pass is off */
    end(): void;
    /**
     * Resolves when this arming stands down, immediately when nothing is armed.
     * What a host waits on before paying for an expensive mount.
     */
    settled(): Promise<void>;
}
export interface ArmingOptions {
    /**
     * How long to wait for a run to appear before standing down anyway, in ms
     * (default 4000). The backstop for a crossing that never produced a pass.
     */
    deadline?: number;
    /** run whenever the arming stands down — where a host clears its own flags */
    onStandDown?: () => void;
}
export declare function createArming(options?: ArmingOptions): Arming;
//# sourceMappingURL=arming.d.ts.map