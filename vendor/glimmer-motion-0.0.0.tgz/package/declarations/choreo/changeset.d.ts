/**
 * boxel-motion's Changeset: the sprites one render pass produced, and the
 * spritesFor / spriteFor queries its transitions selected them with.
 */
import type { Bounds, ChangesetLike, Query, Sprite } from './types.ts';
export declare class Changeset implements ChangesetLike {
    readonly inserted: Sprite[];
    readonly kept: Sprite[];
    readonly removed: Sprite[];
    /**
     * The box a `{{beacon}}` claimed this pass, or null if nothing claimed that
     * name. It is a measurement, not a sprite: a beacon is never inserted, kept
     * or removed, and a missing one is a no-op for whatever wanted to borrow it.
     *
     * Closed over rather than stored as a field, so this class stays structurally
     * identical to ChangesetLike — a property function written against the
     * concrete Changeset must still accept the interface it is handed.
     */
    readonly beacon: (name: string) => Bounds | null;
    /**
     * The camera zoom the world was measured under (§6.3). Every box in this
     * changeset is a page-space measurement taken through the region's frame
     * transform, but a step's values are written in the sprite's own local
     * space — so geometry that becomes inline pixels must be divided back by
     * this before it is animated. 1 when the frame is at rest.
     */
    readonly measureZoom: number;
    /** the frame's own size in local pixels, from the same final layout */
    readonly frame?: {
        height: number;
        width: number;
    };
    /** what the page shows behind this region — see ChangesetLike.ground */
    readonly ground?: string;
    constructor(inserted: Sprite[], removed: Sprite[], kept: Sprite[], beacons?: Map<string, Bounds>, measureZoom?: number, frame?: {
        height: number;
        width: number;
    }, ground?: string);
    get all(): Sprite[];
    /** something happened this pass that a choreography could animate */
    get dirty(): boolean;
    sprites(query: Query | Query[]): Sprite[];
    sprite(query: Query | Query[]): Sprite | null;
}
export default Changeset;
//# sourceMappingURL=changeset.d.ts.map