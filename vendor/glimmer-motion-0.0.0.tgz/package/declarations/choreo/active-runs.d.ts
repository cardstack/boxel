import type { ChoreoRun } from './run.ts';
/** Every live run, shared by external transports and the test helpers. */
export declare const activeRuns: Set<ChoreoRun>;
/** Runs retained by mounted regions, including a finished run that can still be scrubbed. */
export declare const controllableRuns: Set<ChoreoRun>;
/** A snapshot of the document's live runs for external transports. */
export declare function getActiveChoreoRuns(): readonly ChoreoRun[];
/** A snapshot of mounted runs an external player may seek in either direction. */
export declare function getControllableChoreoRuns(): readonly ChoreoRun[];
//# sourceMappingURL=active-runs.d.ts.map