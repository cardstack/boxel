import type { Bounds } from './types.ts';
export declare function registerBeacon(name: string, element: Element): () => void;
/**
 * Measure every live beacon, in the same window the region measures `final`.
 *
 * Re-measured every pass, never cached: the trash can move without the list
 * rendering at all — a header that hides, a column that resizes, a scroll.
 */
export declare function measureBeacons(root: DOMRect): Map<string, Bounds>;
/**
 * Forget every claimed name. The registry outlives any one owner, so a test
 * that tore down mid-flight would otherwise leave a dead element holding a
 * name the next test wants — first-wins turns into first-test-wins.
 * `setupMotion(hooks)` calls this; nothing in an app should.
 */
export declare function resetBeacons(): void;
/** `{{c.beacon 'trash'}}` — a named point, not a sprite query */
export interface BeaconRef {
    beacon: string;
}
export declare const isBeaconRef: (v: unknown) => v is BeaconRef;
//# sourceMappingURL=beacons.d.ts.map