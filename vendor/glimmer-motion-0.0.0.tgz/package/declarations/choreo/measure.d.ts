/**
 * One measurement layer, for everything that measures.
 *
 * The region and the beacon registry both turn a DOMRect into the three spaces
 * a step can ask for — page, region-relative, offset-parent-relative — and they
 * have to agree exactly, because a Move routinely reads one sprite's `page` and
 * another's. Ember Animated learned the same thing the hard way and ended up
 * with a single bounds module; two copies of `minus` that drift by a scroll
 * offset produce a flight that lands next to its target, which is the kind of
 * bug that looks like a spring problem for a day.
 */
import type { Bounds, Rect } from './types.ts';
/** a box in page space */
export declare const rect: (r: DOMRect) => Rect;
/** `a` expressed relative to `b`'s top-left, keeping a's size */
export declare const minus: (a: DOMRect, b: DOMRect) => Rect;
/** an element's box together with the box it is positioned inside */
export interface Snapshot {
    el: DOMRect;
    /** the computed background at measure time — see Bounds.paint */
    paint?: string;
    parent: DOMRect;
    /** the declared subject's box at measure time — see Bounds.substance */
    substance?: DOMRect;
}
/**
 * The shrink-wrap of `el`'s contents — the ink — not the stretched layout
 * box. A full-bleed title (`left:0; right:0; width:auto`) still has a
 * word-sized range; Crossing crop must match THAT, or the type explodes
 * into a viewport strip. Empty / collapsed → undefined, so the frame wins.
 */
export declare const inkBox: (el: Element) => DOMRect | undefined;
/** the containing block a `position: absolute` child would be placed against */
export declare const offsetBox: (el: Element) => DOMRect;
export declare const measure: (el: Element) => Snapshot;
/** the three spaces, from a snapshot and the region's own box */
export declare const boundsOf: (snap: Snapshot, root: DOMRect) => Bounds;
/** measure an element straight into bounds — what a beacon needs */
export declare const measureBounds: (el: Element, root: DOMRect) => Bounds;
//# sourceMappingURL=measure.d.ts.map