import type { ChangesetLike, Compiled, Cue, DeliveryOrder, Sprite, TimelineNode } from './types.ts';
/**
 * The rung each index takes on the stagger ladder, under a delivery order.
 * 'center' delivers from the middle outward; 'random' shuffles per run —
 * seeded input is the native driver's requirement, not this one's.
 */
export declare function ladder(n: number, order: DeliveryOrder): number[];
export default function compile(tree: TimelineNode[], cs: ChangesetLike): Compiled;
/**
 * A replacement pass's continuity cue (§3.1): the prior run was driving
 * this sprite through space and the new score does not name it. Unnamed
 * it would be released to its rest in one frame — the whole-bay snap —
 * so the region completes the score: one shape-matched move from the
 * painted box (which is what a mid-flight sprite's `initial` IS, by
 * design) to its rest. Transform-only, so a continuation can never
 * reflow the scene it is tidying; on the interrupted cue's own spring
 * when it had one, so the carry-on keeps the flight's character.
 */
export declare function continuation(sprite: Sprite, cs: ChangesetLike, inherited?: Record<string, unknown>): Cue | null;
/**
 * Whether two compiled scores are the SAME statement — used by the region
 * to keep an in-flight run when an unrelated render replays the pass (the
 * render detector is volatile by design, so on a busy page every region
 * re-passes on every app render; a neighbouring demo writing tracked state
 * per frame must not restart this region's clock).
 *
 * The comparison is deliberately conservative. A FLIGHT is measured off the
 * page and is not comparable by value: any cue carrying one makes the scores
 * different, and the pass replays exactly as it always did. Values that ARE
 * comparable (targets, transitions, delivery plans, holds, camera aims)
 * compare structurally, so an edit that retimes or re-aims anything replays.
 *
 * Tethers, raises and scrolls used to be lumped in with flights, and that was
 * wrong in a way that only showed up on standing annotations: a wire that is
 * simply ON was recompiled to the identical statement on every pass and, being
 * declared different every time, had its run torn down and rebuilt — the path
 * element removed from the layer and a new one appended, sixty times a second
 * on a busy page. None of the three carries measured geometry in its cue: a
 * tether is two sprites and a function, a raise is a sprite and a flag, a
 * scroll is a sprite and an alignment. They compare by IDENTITY, which is
 * exactly what "the same statement" means for them — and it matters most for
 * the scroll, where replacing the cue is a visible restart of the scroll.
 */
export declare function sameScore(a: Cue[], b: Cue[]): boolean;
//# sourceMappingURL=compile.d.ts.map