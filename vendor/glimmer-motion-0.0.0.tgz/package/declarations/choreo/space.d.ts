/**
 * The coordinate contract (docs/planes-and-cameras.md).
 *
 * A plane's camera is pure arithmetic over frozen numbers: with
 * transform-origin pinned at 0 0, the applied transform is
 * `translate(x + (1−z)·P) scale(z)` for aim point P (§6.3). Because it
 * is arithmetic, it is invertible WITHOUT reading the DOM — and these
 * two inverses are the whole compositor ⇄ plane-local ⇄ viewport
 * conversion: cross-plane flights, cross-plane hit testing, and
 * eventually cross-plane drag all reduce to them.
 *
 * A plane that scrolls adds its scroll offset to the same arithmetic —
 * the one place a DOM read (the scroll position) legitimately enters,
 * read once per conversion, never per frame.
 */
import type { CameraState, Rect } from './types.ts';
export interface PlanePoint {
    x: number;
    y: number;
}
/**
 * The translate the camera actually applies at aim point `aim` — the
 * same algebra `applyCamera` paints with. At z = 1 the aim term
 * vanishes: an unpanned camera is exactly the identity.
 */
export declare function appliedCamera(cam: CameraState, aim?: PlanePoint): PlanePoint;
/** plane-local box → page space, through the plane's camera and scroll */
export declare function toPage(local: Rect, cam: CameraState, aim?: PlanePoint, scroll?: PlanePoint): Rect;
/** page-space box → the plane's local space: `(page − applied)/z + scroll` */
export declare function toLocal(page: Rect, cam: CameraState, aim?: PlanePoint, scroll?: PlanePoint): Rect;
//# sourceMappingURL=space.d.ts.map