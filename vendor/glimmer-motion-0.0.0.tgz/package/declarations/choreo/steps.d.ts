/**
 * The timeline, declared in the template. Each step renders a hidden marker
 * so the region can read the tree back in document order — nesting in the
 * markup IS the sequence/parallel nesting. Nothing here animates; the region
 * compiles these into cues when a render pass produces a changeset.
 */
import Component from '@glimmer/component';
import { type AnchorRef } from './anchors.ts';
import type { BeaconRef } from './beacons.ts';
import type { GestureRef } from './gesture.ts';
import type { Block, Camera3DWaypoint, DeliveryBy, DeliveryOrder, DeriveContext, Easing, PropValue, Query, Rect, SpringSpec, TimelineNode } from './types.ts';
/** the steps directly inside an element, in document order; a nested <Choreo> is another region's */
export declare function collect(el: Element): TimelineNode[];
/**
 * The template speaks seconds, as Motion does; the compiler's clock is ms.
 * A composite step writes node literals, which are BELOW that boundary —
 * so it converts its own seconds args here, and `undefined` stays
 * `undefined` so an unset arg still means "take the default".
 */
export declare function toMs<T extends number | undefined>(seconds: T): T extends number ? number : number | undefined;
/** the args every step shares — a composite step extends this */
export interface StepArgsBase {
    [prop: string]: unknown;
    /** `{{at 'name' 0.4}}` / `{{after 'name' 0.2}}` — start against a named step */
    at?: AnchorRef;
    /** seconds before the step starts, inside its slot */
    delay?: number;
    /** a label other steps may anchor against */
    name?: string;
    /** seconds between one matched sprite and the next, in document order */
    stagger?: number;
}
/** …and the args of a step that names sprites */
export interface StepArgs extends StepArgsBase {
    of: Query | Query[];
}
/**
 * The base every step is built on, and the public seam for a COMPOSITE
 * step — a new word in the timeline that expands into the built-in
 * vocabulary. `c.Crossing` is one, and is written in nothing but this.
 *
 * Subclass it, implement `node()`, and render the component anywhere
 * inside a `<Choreo>`: the region reads the tree back in document order
 * and your node takes its place in it.
 *
 * ```gts
 * export class Reveal extends StepComponent<StepArgs & { rise?: number }> {
 *   node(): TimelineNode {
 *     const { of, name, rise = 12 } = this.args;
 *     return {
 *       at: this.args.at,
 *       children: [
 *         { kind: 'tween', generic: true, of, ms: 240, props: { opacity: [0, 1] } },
 *         { kind: 'tween', generic: true, of, ms: 240, props: { y: [rise, 0] } },
 *       ],
 *       kind: 'parallel',
 *       name,
 *     };
 *   }
 * }
 * ```
 *
 * **`node()` is called on every pass**, and its result is fingerprinted to
 * decide whether an edited timeline replays the run. So it must be pure
 * and cheap: no measurement, no DOM writes, no tracked writes (a tracked
 * write re-renders, which replays the pass, which calls `node()`). And
 * because functions in the tree are compared by identity, a `node()` that
 * allocates a fresh closure per call declares an edit on every pass —
 * hoist property functions to module scope.
 *
 * Two conventions worth keeping: mark children `generic: true` so a
 * sibling step can claim a sprite away from your defaults (the yield
 * rule, §4.7), and derive any inner `name` from your own `@name` so two
 * of your step in one timeline do not collide.
 */
export declare abstract class StepComponent<A extends StepArgsBase> extends Component<{
    Args: A;
}> {
    abstract node(): TimelineNode;
    mark: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: Element;
    }>;
}
export declare class Tween extends StepComponent<StepArgs & {
    /** split a text sprite's delivery: by word, character, or paragraph */
    by?: DeliveryBy;
    /** seconds, as Motion counts them */
    duration: number;
    ease?: Easing;
    order?: DeliveryOrder;
    /** extra plays after the first; `Infinity` is an ambient loop whose phase rides the run clock */
    repeat?: number;
    repeatType?: 'loop' | 'mirror' | 'reverse';
    /** Normalized keyframe offsets, one per value in every keyframe track. */
    times?: number[];
}> {
    node(): TimelineNode;
}
export declare class Spring extends StepComponent<StepArgs & {
    by?: DeliveryBy;
    order?: DeliveryOrder;
    spring?: SpringSpec;
}> {
    node(): TimelineNode;
}
export declare class Move extends StepComponent<StepArgs & {
    /** seconds; with @ease, the tween form of the flight */
    duration?: number;
    ease?: string | readonly number[];
    /** `{{c.beacon 'compose'}}` or `{{c.gesture}}` — fly in from that box */
    from?: BeaconRef | GestureRef;
    /** an SVG path for the journey, drawn from where the sprite stands */
    path?: string;
    /** 'auto' orients along the tangent; a number adds a constant offset */
    rotate?: 'auto' | number;
    size?: boolean | 'crop' | 'scale';
    /** measure the delta in 'page' (default) or the sprite's 'parent' space */
    space?: 'page' | 'parent';
    spring?: SpringSpec;
    /** counterpart skins: 'during' (default), 'settle', or 'none' */
    swap?: 'during' | 'none' | 'settle';
    /** `{{c.beacon 'trash'}}` — fly out to that box rather than to where the sprite landed */
    to?: BeaconRef;
}> {
    node(): TimelineNode;
}
export declare class Hold extends StepComponent<StepArgs & {
    duration?: number;
    fill?: boolean;
}> {
    node(): TimelineNode;
}
/**
 * `<c.Wait />` — a hole in a sequence. It has no subject: `@of` is accepted
 * (a wait can be laddered across sprites with `@stagger`) but never needed.
 */
export declare class Wait extends StepComponent<StepArgsBase & {
    duration: number;
    of?: Query | Query[];
}> {
    node(): TimelineNode;
}
/**
 * `<c.Perform />` — a semantic command on the timeline (§C4). It occupies
 * an instant, positioned like any step (sequence order, `@at`, `@delay`),
 * and carries `@action` (required), `@target` and `@payload` to the
 * region's dispatcher (`<Choreo @onPerform>`). The fold's law: forward
 * playback dispatches it once as the clock crosses it; a seek past it
 * includes it; a seek before it resets the host and replays the remaining
 * prefix. Commands are idempotent statements of state — `lightbox.open`,
 * never `lightbox.toggle`.
 */
export declare class Perform extends StepComponent<StepArgsBase & {
    action: string;
    payload?: unknown;
    target?: string;
}> {
    node(): TimelineNode;
}
/**
 * `<c.Scroll />` — animate the sprite's scroll container so the sprite lands
 * at `@align`; occupies the sequence like any step (§6.1).
 */
/**
 * `<c.Attach @region @duration />` — drive another region's run over a
 * window of this one's clock. Positioned like any step (sequence order,
 * `@at`, `@delay`); `@in` and `@rate` map the window onto the child's own
 * seconds; `@end` says what happens past it; `@exact` refuses a child
 * that cannot be driven exactly (a spring, a follow).
 */
export declare class Attach extends StepComponent<StepArgsBase & {
    duration: number;
    end?: 'hold' | 'remove';
    exact?: boolean;
    in?: number;
    rate?: number;
    region: string;
}> {
    node(): TimelineNode;
}
export declare class Scroll extends StepComponent<StepArgs & {
    align?: 'center' | 'end' | 'start';
    duration?: number;
}> {
    node(): TimelineNode;
}
/**
 * `<c.Raise />` — promote the sprites to the region's elevated layer for the
 * span of its block (or `@duration`): above every stacking context and clip
 * in the region, with measured continuity both ways. `@shadow` casts on the
 * layer below (§6.3).
 */
export declare class Raise extends StepComponent<StepArgs & {
    duration?: number;
    shadow?: boolean;
}> {
    node(): TimelineNode;
}
/**
 * `<c.Camera />` — the region's frame as a step (§6.3): `@zoom` / `@x` /
 * `@y` animate the scene, `@origin` aims the zoom at a sprite, `@steady`
 * names sprites that keep their size against it (damped by default).
 * `@fit` is the other, more common shape — dive on this sprite and CENTRE
 * it, zoom and pan computed from rest-layout geometry (`@margin` sets the
 * share of the frame it fills); pass `null` to fit nothing: back to rest.
 */
export declare class Camera extends StepComponent<StepArgsBase & {
    duration?: number;
    ease?: Easing;
    fit?: Query | null;
    margin?: number;
    of?: Query | Query[];
    origin?: Query;
    spring?: SpringSpec;
    steady?: Query | Query[];
    x?: number;
    y?: number;
    zoom?: number;
}> {
    node(): TimelineNode;
}
/**
 * `<c.Camera3D @yaw={{-24}} @pitch={{-6}} @dolly={{0.9}} />` — the shot,
 * for a scene Choreo is not the one drawing.
 *
 * `c.Camera` moves the region's own frame, which is a 2D transform on real
 * DOM. A 3D scene has no such frame: its camera belongs to whatever is
 * rendering it. So this step carries the POSE and nothing else — yaw and
 * pitch in degrees, dolly as a multiple of the host's own framing — and
 * the region hands it to `@onCamera3D` every frame it changes. The host
 * applies it to three.js, to a CSS 3D stage, to anything that takes three
 * numbers.
 *
 * What Choreo keeps is the part it is actually good at: the pose is a pure
 * function of the clock, so a scrub lands the shot exactly where playing
 * there would, and a preset expands into this one seekable cue rather than
 * a second scheduler.
 *
 * `@by` makes it relative — added to the pose in force when the cue
 * starts, the way `Pan` and `SlowZoom` are relative — so a drift composes
 * with whatever shot preceded it.
 */
export declare class Camera3D extends StepComponent<StepArgsBase & {
    by?: boolean;
    dolly?: number;
    duration?: number;
    ease?: Easing;
    /** the orbit centre, in the host's scene units — tweened with the pose */
    look?: {
        x: number;
        y: number;
        z: number;
    };
    of?: Query | Query[];
    pitch?: number;
    /** smoothing window for a path, seconds — see Camera3DStep.settle */
    settle?: number;
    spring?: SpringSpec;
    /** the path's grip, 0 lively .. 1 linear — see Camera3DStep.tension */
    tension?: number;
    /** waypoints for a spline path — see Camera3DStep.through */
    through?: Camera3DWaypoint[];
    x?: number;
    y?: number;
    yaw?: number;
}> {
    node(): TimelineNode;
}
/**
 * `<c.Frame @of={{c.id 'hero'}} @padding={{0.8}} />` — fit-and-centre the
 * target: the fit camera under its editorial name. `@padding` is the
 * share of the frame the target fills on whichever axis fits first.
 */
export declare class Frame extends StepComponent<StepArgsBase & {
    duration?: number;
    ease?: Easing;
    of: Query | null;
    padding?: number;
    spring?: SpringSpec;
    steady?: Query | Query[];
}> {
    node(): TimelineNode;
}
/**
 * `<c.Aim @of={{c.id 'hero'}} />` — recentre the picture on the target
 * with the zoom HELD: the reframe that does not change magnification.
 */
export declare class Aim extends StepComponent<StepArgsBase & {
    duration?: number;
    ease?: Easing;
    of: Query;
    spring?: SpringSpec;
    steady?: Query | Query[];
}> {
    node(): TimelineNode;
}
/**
 * `<c.Pan @x={{40}} @y={{-20}} />` — shift the picture by exactly this
 * many pixels from wherever it stands. Relative on purpose: a pan after
 * any shot means "from here", not "to there".
 */
export declare class Pan extends StepComponent<StepArgsBase & {
    duration?: number;
    ease?: Easing;
    spring?: SpringSpec;
    steady?: Query | Query[];
    x?: number;
    y?: number;
}> {
    node(): TimelineNode;
}
/**
 * `<c.SlowZoom @by={{1.05}} @duration={{2}} />` — multiply the zoom in
 * force: the push-in (or, below 1, the pull-back) that gives a hold its
 * life. The aim in force is kept, so it pushes toward what the previous
 * shot was looking at.
 */
export declare class SlowZoom extends StepComponent<StepArgsBase & {
    by: number;
    duration?: number;
    ease?: Easing;
    spring?: SpringSpec;
    steady?: Query | Query[];
}> {
    node(): TimelineNode;
}
/**
 * `<c.Tether />` — geometry continuously derived from sprites (§6.1):
 * `@path` receives both endpoints' region-relative boxes every frame and
 * returns the path data the wire draws.
 */
export declare class Tether extends StepComponent<StepArgsBase & {
    duration?: number;
    from: Query;
    of?: Query | Query[];
    path: (from: Rect, to: Rect) => string;
    to: Query;
}> {
    node(): TimelineNode;
}
/**
 * `<c.Crossing />` — the canned scene crossing (§4.7): what only the old
 * scene had fades as the flight lifts off, everything paired flies (skins
 * swapping per `@swap`), and what only the new scene has fades in near the
 * settle. One step in the template; a whole overlapped score on the clock —
 * Keynote's Magic Move does not wait for the dissolve to finish before the
 * movers leave, and a crossing that does reads as three acts, not one.
 *
 * It is also the reference COMPOSITE step, and deliberately written in
 * nothing but the public seam (`StepComponent`, `toMs`, `at`, and node
 * literals): if this needed a privilege an author could not have, the
 * contract on `StepComponent` would be a lie.
 */
export declare class Crossing extends StepComponent<StepArgsBase & {
    /** seconds to fade what only the new scene has */
    arrive?: number;
    /** the tween form of the flight */
    duration?: number;
    ease?: Easing;
    /** seconds to fade what only the old scene had */
    leave?: number;
    /** arrivals start at this fraction of the flight — near the settle */
    overlap?: number;
    /**
     * The flight's size mode. Default `'crop'` — uniform scale from
     * width, tops pinned, extra height clipped. `'scale'` stretches
     * per-axis; `true` writes layout width/height (reflows a grid row).
     */
    size?: boolean | 'crop' | 'scale';
    spring?: SpringSpec;
    /** the counterpart-skin policy, forwarded to the flight */
    swap?: 'during' | 'none' | 'settle';
}> {
    /**
     * The flight is addressable from outside — `{{at 'page:flight' 0.5}}`
     * for a step that wants to ride the move itself. Derived from this
     * crossing's own `@name` rather than fixed, so two crossings in one
     * timeline do not collide over it; unnamed, it takes a per-instance
     * number, which is stable for the life of the component and so does not
     * disturb the tree fingerprint between passes.
     */
    private flightName;
    node(): TimelineNode;
}
/**
 * `<c.Follow />` — a value DERIVED from the scene rather than interpolated
 * between two keyframes (§4.10). `@to` names what to read; `@read` gets
 * the pass's measurements every frame — each source's resting boxes
 * (`from`, `to`) and its composed position this frame (`now`), plus the
 * follower's own `rest` — and returns the properties to write; `@rest`
 * says what those properties are when nothing is driving them, so a
 * measure pass can put the element back.
 *
 * ```gts
 * <c.Follow @of={{c.id 'badge'}} @to={{c.id 'card'}}
 *           @read={{corner}} @rest={{hash x=0 y=0}} />
 * ```
 *
 * `@read` never sees the live page. Everything it is handed was measured
 * by the pass or composed from the run's own values, so it cannot read
 * back what it wrote last frame and it cannot force a style recalculation
 * mid-move — pure by construction, and correct under interruption because
 * a replacement pass re-measures (docs/postmortem-follow.md).
 *
 * Three things it is not: it is not accelerated (a derived value is
 * computed on the main thread, every frame — the price, and the same one
 * `c.Tether` pays); it may not write layout, only transform, opacity and
 * filter; and `@read` must still be a pure function of its context,
 * because the run is scrubbable in both directions and a value with
 * memory could not be sought back to.
 */
export declare class Follow extends StepComponent<StepArgs & {
    duration?: number;
    read: (ctx: DeriveContext) => Record<string, PropValue>;
    rest: Record<string, PropValue>;
    to: Query | Query[];
}> {
    node(): TimelineNode;
}
/**
 * `<c.Gate />` — park the run until `c.advance()`; `@delay` opens it by
 * itself after that many seconds (§4.1). A gate is a pause, and a pause is
 * a total order: it may only stand in a sequence that no parallel contains.
 */
export declare class Gate extends Component<{
    Args: {
        delay?: number;
    };
}> {
    node(): TimelineNode;
    mark: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: Element;
    }>;
}
/**
 * A block is a step's equal to the anchor system: it takes `@name`, `@at`
 * and `@delay` on the same terms, so a composite step — a `node()` that
 * returns a block — is something the rest of the score can point at.
 */
declare abstract class BlockComponent extends Component<{
    Args: {
        /** `{{at 'name' 0.4}}` / `{{after 'name'}}` — start against a named step or block */
        at?: AnchorRef;
        /** seconds before the block's contents start, inside its slot */
        delay?: number;
        /** a label other steps may anchor against; the block's span is its contents */
        name?: string;
    };
    Blocks: {
        default: [];
    };
}> {
    abstract readonly kind: Block['kind'];
    private el?;
    node(): Block;
    mark: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: Element;
    }>;
}
export declare class Sequence extends BlockComponent {
    readonly kind = "sequence";
}
export declare class Parallel extends BlockComponent {
    readonly kind = "parallel";
}
export {};
//# sourceMappingURL=steps.d.ts.map