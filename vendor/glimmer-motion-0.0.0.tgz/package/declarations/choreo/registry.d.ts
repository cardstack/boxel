/**
 * How a participant finds its region: the nearest `[data-choreo]` ancestor, by
 * DOM — the same discovery <LayoutGroup> and <MotionConfig> use, so nothing
 * has to be threaded through the tree. No imports from node.ts here: node.ts
 * imports this.
 */
import type { ChoreoRun } from './run.ts';
import type { ChoreoNode, TimelineNode } from './types.ts';
/** anything that can put a node on a region's timeline — a step component, or a lane from outside */
export interface ChoreoProvider {
    node(): TimelineNode;
}
export interface ChoreoHost {
    /** a destroyed participant asks whether the region still needs its element; true → the region unmounts it later */
    claim(node: ChoreoNode): boolean;
    /**
     * SPIKE (Lane): a provider from OUTSIDE the region's markup — a parent's
     * lane addressed at this region — whose node joins the tree the region
     * collects on every pass, after its own steps. Returns the remover.
     */
    contribute(provider: ChoreoProvider): () => void;
    /** the run the region is playing or holding, for an attachment to drive; null between runs */
    currentRun(): ChoreoRun | null;
    register(node: ChoreoNode): () => void;
}
export declare function setChoreoHost(el: Element, host: ChoreoHost | undefined): void;
export declare function closestChoreo(el: Element): ChoreoHost | undefined;
/** the host of a region element itself (not an ancestor's) */
export declare function choreoHostAt(el: Element): ChoreoHost | undefined;
/** the host of the region rendered with `@id` — a lane's way of naming the region it plays in */
export declare function choreoHostById(id: string): ChoreoHost | undefined;
//# sourceMappingURL=registry.d.ts.map