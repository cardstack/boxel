/**
 * The cosine easings, recovered from boxel-motion (`easings/cosine.ts` at
 * `cardstack/boxel@394503e3b7^`) — the ones its own flagship transition used.
 *
 * `easeInAndOut` is the interesting one: a raised cosine has zero slope at both
 * ends, so an animation interrupted at t=0 inherits none of its own curve and
 * all of whatever it is replacing. That is the property Ember Animated leans on
 * to make a summed corrective curve continuous; here the same shape is simply
 * available as an `@ease`.
 *
 *   <c.Tween @of={{c.kept 'card'}} @opacity={{1}} @ms={{300}} @ease={{easeIn}} />
 *
 * `@ease` also takes an engine easing name or a cubic-bezier as four numbers;
 * these exist because a bezier cannot express a raised cosine exactly.
 */
/** a raised cosine: zero slope at both ends */
export declare function easeInAndOut(t: number): number;
export declare function easeIn(t: number): number;
export declare function easeOut(t: number): number;
//# sourceMappingURL=easings.d.ts.map