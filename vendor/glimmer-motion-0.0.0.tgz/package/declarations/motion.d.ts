import type Owner from '@ember/owner';
import Modifier, { type ArgsFor } from 'ember-modifier';
import { type MotionEl, type MotionProps } from './node.ts';
export type { MotionEl, MotionProps } from './node.ts';
export { flushPendingMounts } from './node.ts';
interface Signature {
    Args: {
        Named: MotionProps;
        Positional: [];
    };
    Element: MotionEl;
}
/** `{{motion …}}` — the modifier. Named `motion` where it is used; the class name is for stack traces. */
export declare class MotionModifier extends Modifier<Signature> {
    private readonly node;
    constructor(owner: Owner, args: ArgsFor<Signature>);
    modify(element: MotionEl, _pos: [], named: MotionProps): void;
}
export default MotionModifier;
//# sourceMappingURL=motion.d.ts.map