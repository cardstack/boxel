export declare const beacon: import("ember-modifier").FunctionBasedModifier<{
    Args: {
        Positional: [string];
        Named: import("ember-modifier/-private/signature").EmptyObject;
    };
    Element: Element;
}>;
export default beacon;
//# sourceMappingURL=beacon.d.ts.map